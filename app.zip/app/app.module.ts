﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {  CustomerComponent } from './app.customercomponent';
import  { HttpClientModule }  from '@angular/common/http';
import {FormsModule} from '@angular/Forms';
import {Routes,RouterModule}  from '@angular/router';
import {   BookingComponent } from './app.bookingcomponent';
//import { ReactiveFormsModule } from '@angular/forms'; 
import { SearchTypeComponent}  from './app.searchtypecomponent';
import { SearchIdComponent}  from './app.searchcomponentid';
const route:Routes=[

{  path :'addcustomer',component:  CustomerComponent },
   { path :'addbooking',component: BookingComponent },

   { path :'searchid',component:  SearchIdComponent},
    { path :'searchtype',component: SearchTypeComponent }
];


@NgModule({
    imports: [
        BrowserModule,HttpClientModule ,FormsModule, RouterModule.forRoot(route)
        
    ],
    declarations: [
        AppComponent,CustomerComponent, BookingComponent, SearchIdComponent, SearchTypeComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }