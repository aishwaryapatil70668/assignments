import { Component,OnInit } from '@angular/core';
import { BookingService } from './app.bookingservice';
import { Customer } from './app.customer';
import {Room } from './app.room';
@Component({
    selector: 'book-app',
    templateUrl: 'app.booking.html'
})



export class BookingComponent  {

//  book=new FormGroup({
// id : new FormControl(''),
// totalAmount : new FormControl(''),
// custId : new FormControl('')

// });  

model:any={};

constructor(private bookingservice:  BookingService ){
}

roomdata=false;

rooms:Room[]=[];

room={ number:0,   type:'', price:0  };


 addRoom()
 {
    console.log(this.model);
    this.roomdata=true;
 }

addRooms()
{
this.rooms.push(this.room);
console.log(this.rooms);
   this.room={
      number:0,   type:'', price:0
   }
}

 addBooking()
 {  this.rooms.push(this.room);
     this.model['rooms']=this.rooms;
    console.log(this.model);
    this.bookingservice.addAllBooking(this.model).subscribe((data=>console.log(data)));
 }
}