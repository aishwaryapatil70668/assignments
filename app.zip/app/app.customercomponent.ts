import { Component,OnInit } from '@angular/core';
import { BookingService } from './app.bookingservice';
import { Customer } from './app.customer';
//import { FormControl, FormGroup } from "@angular/forms"; 
@Component({
    selector: 'cust-app',
    templateUrl: 'app.customer.html'
})


export class CustomerComponent  {


//  custForm=new FormGroup ({
// id  : new FormControl(''),
// name : new FormControl(''),
// mobileNumber: new FormControl(''),
// email : new FormControl(''),
// address: new FormControl('')
// });  


model:any={};

constructor(private bookingservice:  BookingService ){
}

 addCustomer()
 {
    console.log(this.model);
    this.bookingservice.addAllCustomer(this.model).subscribe((data:any)=> console.log(data));
 }
}