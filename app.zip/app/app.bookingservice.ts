import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
//import { Observable } from "rxjx";
import {Room } from './app.room';
import {Booking }  from './app.booking';
import { Customer } from './app.customer';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
@Injectable({
providedIn:'root'    
})
export class BookingService{

constructor(private http:HttpClient){}



addAllCustomer(cust:any)
{
let input= new FormData();
input.append("id",cust.id);  //"id "= postman key   value =are form name 
input.append("name",cust.name);
input.append("mobileNumber",cust.mobileNumber);
input.append("email",cust.emai);
input.append("address",cust.address);

return this.http.post("http://localhost:9090//booking/addCustomer",input).pipe(
        retry(1),
        catchError(this.handleError)
      );
}



addAllBooking(book:any):any
{
let i:number=0;    
var input= new FormData();
input.append("id",book.id);  //"id "= postman key   value =are form name 
input.append("totalAmount", book.totalAmount);
input.append("customer.id", book.custId);

while(i<book.rooms.length) {
console.log(i);

input.append("rooms["+i+"].number", book.rooms[i].number);
input.append("rooms["+i+"].type", book.rooms[i].type);
input.append("rooms["+i+"].price", book.rooms[i].price);
i++;
}  
 
return this.http.post("http://localhost:9090//booking/addBooking",input).pipe(
        retry(1),
        catchError(this.handleError)
      );
}



searchbybookingid(id:number)
{
let httpParams = new HttpParams().set("id",id.toString());
return this.http.get("http://localhost:9090//booking/searchid",{params:httpParams}).pipe(
        retry(1),
        catchError(this.handleError)
      );
}  


searchbyroomtype(type:string)
{
let httpParams = new HttpParams().set("type",type);
return this.http.get("http://localhost:9090//booking/searchtype",{params:httpParams}).pipe(
        retry(1),
        catchError(this.handleError)
      );
}  


  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.error}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }





}