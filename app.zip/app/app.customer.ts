export class Customer{
id:number;
name:string;
mobileNumber:number;
email:string;
address:string;
} 