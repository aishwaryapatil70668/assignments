import { Component,OnInit } from '@angular/core';
import { BookingService } from './app.bookingservice';
import { Customer } from './app.customer';
import {Room } from './app.room';
import {Booking }  from './app.booking';

@Component({
    selector: 'searchtype-app',
    templateUrl: 'app.searchtype.html'
})

export class SearchTypeComponent  {

constructor(private bookingservice:  BookingService ){}

rooms:Room[];

type:string;

searchByType(){

this.bookingservice.searchbyroomtype(this.type).subscribe((data:any)=>this.rooms=data);

}

}