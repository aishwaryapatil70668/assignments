import { Component,OnInit } from '@angular/core';
import { BookingService } from './app.bookingservice';
import { Customer } from './app.customer';
import {Room } from './app.room';
import {Booking }  from './app.booking';

@Component({
    selector: 'searchod-app',
    templateUrl: 'app.searchid.html'
})



export class SearchIdComponent  {

constructor(private bookingservice:  BookingService ){}

booking:Booking;67

id:number;

searchById(){
this.bookingservice.searchbybookingid(this.id).subscribe((data:any)=>this.booking=data);
}


} 
