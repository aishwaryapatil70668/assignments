

export class Room{

number:number;
type:string;
price:number;

}