
import {Customer } from './app.customer';

import {Room } from './app.room';
export class Booking{
    
id:number;
date:Date;
totalAmount:number;
customer:Customer;
rooms: Room[];

} 