package com.cg.demo.dao;


import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.Product;


@Repository
public class ProductDaoImpl implements ProductDao{

	List<Product> mylist= new LinkedList<>();

	
	
	@Override
	public Product save(Product prod) {
	
		mylist.add(prod);
		return prod;
	}

	@Override
	public List<Product> show() {
	
		return mylist;
	}

	@Override
	public Product findById(int id) {
		
		for (Product proda : mylist) {
		     
			if (proda.getId()==id)
		{
	           return proda;
		}
		}
		return null;
		
	}

	@Override
	public void delete(Product prod) {
		mylist.remove(prod);
	}
}
	
