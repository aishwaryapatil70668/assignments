package com.cg.demo.dao;

import java.util.List;

import com.cg.demo.dto.Product;

public interface ProductDao {
	public Product save(Product prod);
	public List<Product> show();
	public Product findById(int id);
	public void delete(Product prod);
}
