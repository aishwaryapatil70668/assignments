package com.cg.demo.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.demo.dto.Product;
import com.cg.demo.service.ProductService;


@Controller
public class ProductController {

	@Autowired
	ProductService productservice;
	
	@GetMapping("login")
	public String loginPage() {
	return "mylogin";
	}
	
	
	@GetMapping("search")
	public ModelAndView SEAR() {
	return new ModelAndView("search");
	}
	
	@PostMapping("search")
	public ModelAndView searchProduct(@RequestParam("pid") int id, Model m)
	{
		Product product= productservice.searchid(id);
		m.addAttribute("comm", product);
		return new ModelAndView("search");
		
	}
	
	
	@GetMapping("deletep")
	public ModelAndView delete() {
	return new ModelAndView("deletep");
	}
	
	@PostMapping("deletep")
	public ModelAndView deleteProduct(@RequestParam("pid") int id, Model m)
	{
		Product product= productservice.searchid(id);
		m.addAttribute("comm", product);
		productservice.delete(product);
		return new ModelAndView("deletep");
		
	}
	@GetMapping("update")
	public ModelAndView update() {
	return new ModelAndView("update");
	}
	
	@PostMapping("update")
	public ModelAndView updateProduct(@RequestParam("pid") int id,Model m)
	{  

		Product prod= productservice.searchid(id);
		m.addAttribute("comm", prod);
		productservice.show();
		
		return new ModelAndView("update");
		
	}
	
	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user,@RequestParam("pass") String pass)
	{
		if(user.equals("admin") && pass.equals("1234"))
		return "listpage";
		else
		return "error";		
	}
	
	@GetMapping("addpage")
	public ModelAndView getAddProduct(@ModelAttribute("prod") Product pro) //prod-key   pro-value
	{
		List<String> listofcategory= new ArrayList<>();
		listofcategory.add("electronics");
		listofcategory.add("Grocery");
		listofcategory.add("cloths");
		
		return new ModelAndView("addproduct","cato",listofcategory);
		
		//return new ModelAndView("addproduct");
		
	}
	
	
	@GetMapping("showpage")
	public ModelAndView showProduct()
	{
		List<Product> myall=productservice.show();
		return new ModelAndView("showall","showproduct",myall);
		
	}
	
	
	@PostMapping("addproduct")
	public ModelAndView AddProduct(@ModelAttribute("prod") Product pro) {
	//	System.out.println(pro);
		
		Product product= productservice.addproduct(pro);
		
		return new ModelAndView("success","key",product);
		
	}
	

	
	/*@PostMapping("searchpro")
	public ModelAndView searchpro(@ModelAttribute("prod") Product pro) {
	//	System.out.println(pro);
		
		Product product= productservice.searchid(id);
		
		return new ModelAndView("success","key",product);
		
	}*/
	
}
