package com.cg.demo.service;

import java.util.List;

import com.cg.demo.dto.Product;

public interface ProductService {
	
	public Product addproduct(Product prod);
	public List<Product> show();
	public Product searchid(int id);
	public Product update(Product prod);
	public void delete(Product prod);

}
