package com.cg.booking.dao;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import com.cg.booking.dto.Booking;
import com.cg.booking.dto.Customer;
import com.cg.booking.dto.Room;
import com.cg.booking.util.ConnectionDBUtil;

public class BookingDaoImpl implements IBookingDao {
	EntityManager em;

	public BookingDaoImpl() {
		em=ConnectionDBUtil.em;
	}
	public Booking save(Booking booking) {

		Customer customer=em.find(Customer.class,booking.getCustomer().getId());
		List<Room> roomList=new ArrayList<Room>();
	
		for (Room room : booking.getRoom()) {
			room=em.find(Room.class,room.getId());
			roomList.add(room);
		}
		booking.setRoom(roomList);
	//	System.out.println(roomList);
		em.getTransaction().begin();
		em.merge(booking);
	//	Room room=new Room();
		//room=em.find(Room.class, booking.getRoom().g);
	
		
		em.getTransaction().commit();
		return null;	 

	}
	public Booking findByBookId(int id)  {
		Booking book= new Booking();
		book = em.find(Booking.class, id);
		return book;

	}
}
