package com.cg.booking.dao;

import javax.persistence.EntityManager;
import com.cg.booking.dto.Customer;
import com.cg.booking.util.ConnectionDBUtil;

public class CustomerDaoImpl implements  ICustomerDao{
		
EntityManager em;

		public CustomerDaoImpl() {
			em=ConnectionDBUtil.em;
		}

		public Customer save(Customer customer) {
			em.getTransaction().begin();
	
			em.persist(customer);
		//	em.merge(customer);
			em.getTransaction().commit();
			
			return null;
		}
	}
