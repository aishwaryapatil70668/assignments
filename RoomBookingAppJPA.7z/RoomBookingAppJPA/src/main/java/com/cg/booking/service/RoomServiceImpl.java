package com.cg.booking.service;
import java.util.List;

import com.cg.booking.dao.IRoomDao;
import com.cg.booking.dao.RoomDaoImpl;
import com.cg.booking.dto.Room;

public class RoomServiceImpl implements  IRoomService {
	IRoomDao roomDao;
	public RoomServiceImpl() {
		roomDao=new RoomDaoImpl();
	}
	public List<Room> searchByRoomType(String type) {
	
			return roomDao.findByRoomType(type);
	}
	public Room addRoom(Room room) {
		
		
		
		return roomDao.save(room);
	}

}
