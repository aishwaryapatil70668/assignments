package com.cg.product.dao;

import com.cg.demothree.dto.Product;

public interface ProductDao {
	
	public Product addp(Product pro);
	public Product[] show();
	
	

}
