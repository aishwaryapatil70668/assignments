package com.cg.product.dao;

import com.cg.demothree.dto.Product;

public class ProducDao implements ProductDao {

	Product prod[];
	
	int i=0;
	public ProducDao()
	{
		prod=new Product[5];
		
	}
	@Override
	public Product addp(Product pro) {
		// TODO Auto-generated method stub
		
	/*for(int i=0;i<prod.length-1;i++)
	{*/
		prod[i]=new Product();
		prod[i].setId(pro.getId());
				prod[i].setName(pro.getName());	
						prod[i].setPrice(pro.getPrice());
						prod[i].setDescr(pro.getDescr());
	
		
		i++;
		return pro;
	}

	@Override
	public Product[] show() {
		// TODO Auto-generated method stub
		return prod;
	}

}
