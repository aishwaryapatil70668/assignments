package com.cg.demothree.ui;

public class DayShift extends AbstractTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void login() {
		// TODO Auto-generated method stub
		System.out.println("IN Login");
		
	}

	@Override
	public double logout() {
		// TODO Auto-generated method stub
		return 12.5;
	}

}
