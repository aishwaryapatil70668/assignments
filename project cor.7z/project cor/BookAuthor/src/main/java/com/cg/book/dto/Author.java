package com.cg.book.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="author")
public class Author {

	
@Id
@Column(name="aut_id")
private	int id;

@Column(name="aut_name")
private	String name;
@Column(name="aut_mobile")
private int no;	

public Author() {
	
}

public Author(int id, String name, int no) {
	super();
	this.id = id;
	this.name = name;
	this.no = no;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getNo() {
	return no;
}

public void setNo(int no) {
	this.no = no;
}

@Override
public String toString() {
	return "Author [id=" + id + ", name=" + name + ", no=" + no + "]";
}







}


