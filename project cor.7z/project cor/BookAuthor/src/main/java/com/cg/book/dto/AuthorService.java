package com.cg.book.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AuthorService {

EntityManagerFactory emf=Persistence.createEntityManagerFactory("book");
EntityManager em=emf.createEntityManager();	




public void create(int id,String name,int no)
{
	em.getTransaction().begin();
	Author aut=new Author(id,name,no);
	aut.setId(id);
	aut.setName(name);
	aut.setNo(no);	
	em.persist(aut);
	em.getTransaction().commit();
}
	

	
	
}
