package com.cg.booking.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.booking.exception.Exceptions;

public class ConnectionDBUtil {

	static Connection conn;
	public static Connection getConnection()
	{
		Properties ps=new Properties();
		try {
			InputStream it= new FileInputStream("src/main/resources/jdbc.properties");
			ps.load(it);
			if(conn==null)
			{
			if(ps!=null)
				
			{
		String	driver=ps.getProperty("jdbc.driver");
		String	url=ps.getProperty("jdbc.url");
		String	uname=ps.getProperty("jdbc.username");
		String	pass=ps.getProperty("jdbc.password");
		
		Class.forName(driver);
		 conn=	DriverManager.getConnection(url,uname,pass);
			}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new Exceptions("Connection not found");
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Exceptions("Coonection not found");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Exceptions("connection not found");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Exceptions("connection not found");
		}
		
		
		
		
		return conn;
	}
	
	
	
}

