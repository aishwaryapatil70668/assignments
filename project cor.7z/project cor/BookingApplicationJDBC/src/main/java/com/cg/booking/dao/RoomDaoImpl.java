package com.cg.booking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.booking.dto.Room;
import com.cg.booking.exception.Exceptions;
import com.cg.booking.util.ConnectionDBUtil;

public class RoomDaoImpl implements IRoomDao {
	
	public List<Room> findByRoomType(String Type) {
		
		List<Room> roomtype =new ArrayList<Room>();
		Connection con=ConnectionDBUtil.getConnection();
		String query1="SELECT * FROM ROOM WHERE ROOMTYPE= ? ";
		PreparedStatement pst=null;
		try {
				pst=con.prepareStatement(query1);
				pst.setString(1, Type);                                                  
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					Room room= new Room();
					room.setNumber(rs.getInt(2));
					room.setType(rs.getString(3));
					room.setPrice(rs.getBigDecimal(4));
					roomtype.add(room);
				}	
			} catch (SQLException e) {
			e.printStackTrace();
		}finally
 		{
	try
	{		
	
	pst.close();
	}catch(SQLException e)
	{
		throw new Exceptions("connection not closed");	
	}
}
		
		
		if(roomtype.isEmpty())
			throw new Exceptions("RoomType(AC/Non Ac) with this room not found");
		return roomtype;
	}

	
	public Room save(Room room) {
		Connection con=ConnectionDBUtil.getConnection();
		String query1="INSERT INTO ROOM(RoomNumber,RoomType,RoomPrice) VALUES(?,?,?)";
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement(query1);
			pst.setInt(1, room.getNumber());
			pst.setString(2, room.getType());
			pst.setBigDecimal(3, room.getPrice());
			pst.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();	
		}finally
 		{
	try
	{	
	pst.close();
	}catch(SQLException e)
	{
		throw new Exceptions("connection not closed");	
	}
}
		
		
		return null;
	}



}
