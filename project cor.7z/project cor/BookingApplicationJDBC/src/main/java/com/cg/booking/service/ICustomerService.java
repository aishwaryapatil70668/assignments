package com.cg.booking.service;



import com.cg.booking.dto.Customer;

public interface ICustomerService {
	public Customer addCustomer(Customer customer);
	public Customer searchByCustomerId(int id);
	
}
