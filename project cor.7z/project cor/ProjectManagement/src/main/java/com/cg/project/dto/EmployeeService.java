package com.cg.project.dto;

import com.cg.project.dto.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class EmployeeService {
	 EntityManagerFactory emf=Persistence.createEntityManagerFactory("projectmanagement");  
     EntityManager em=emf.createEntityManager();  
   
     public void create(int id, String name, double salary, int pid, String pname) {
		Project pro = new Project(pid,pname);
		em.getTransaction().begin();  
		Employee emp = new Employee(id,name,salary,pro);
		em.persist(pro);
		em.persist(emp);
		em.getTransaction().commit();
	}
     
     public void update(int id, String name, double salary, String pname) {
    	 em.getTransaction().begin(); 
    	 Employee emp = em.find(Employee.class, id);
    	 if(emp!=null) {
    		 Project pro=em.find(Project.class, emp.getProj().getId());
    		 pro.setName(pname);
    		 emp.setSalary(salary);
    		 emp.setName(name);
    		 emp.setProj(pro);
    		 em.persist(pro);
    			em.persist(emp);
    			em.getTransaction().commit();
    	 }
     }
     
     public void remove(int id) {
    	 em.getTransaction().begin(); 
    	 Employee remove=em.find(Employee.class, id);
		 em.remove(remove);
		 em.getTransaction().commit();
     }
     
     public void showDetails(int id) {
    	 em.getTransaction().begin();
    	 Employee emp = em.find(Employee.class, id);
    	 if(emp!=null) {
    	 Project pro=em.find(Project.class, emp.getProj().getId());
    	 System.out.println(pro.getName());
    	 System.out.println(pro.getName()); 
		
    	 }
    	 em.getTransaction().commit();
     }
      
}
