package com.cg.project.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.dto.Employee;
import com.cg.project.dto.Project;

public class Myapplication {

	public static void main(String[] args) {

		
		   EntityManagerFactory emf=Persistence.createEntityManagerFactory("projectdemo");  
	        EntityManager em=emf.createEntityManager();  
	          em.getTransaction().begin();  
	          Scanner sc=new Scanner(System.in);
	          int ch;
	       
	          do
	  		{	 
	  			System.out.println("1.add employee and project");
	  			System.out.println("2.search project id");
	  			System.out.println("3.exit");
	  			
	  			System.out.println("Enter the choice");
	  			ch=sc.nextInt();
	  			switch(ch)
	  			{
	  			case 1:
	  			   
	  				em.getTransaction().begin();   
	  			   Employee emp =new Employee(); 
	  		        Project proj=new Project();
	    	System.out.println("add employee");
	    	System.out.println("enter id\t");
	    	int id=sc.nextInt();
	    	System.out.println("enter name\t");
	    	String ename=sc.next();
	    	System.out.println("enter salary");
	    	double salary=sc.nextDouble();
	    	
	     	System.out.println("add project");
	    	System.out.println("enter project id\t");
	    	int pid=sc.nextInt();
	    	System.out.println("enter project name\t");
	    	String pname=sc.next();
	  		emp.setId(id);
	    	emp.setName(ename);
	    	emp.setSalary(salary);
	    	
	    	proj.setPid(pid);
	    	proj.setPname(pname);
	    	emp.setProj(proj);
	    	
	    	em.persist(proj);
	    	em.persist(emp);
	        em.getTransaction().commit(); 
	    	break;
	    	
	  			case 2:
	  				
	  				 em.getTransaction().begin();  
	  				System.out.println("enter by proj id\t");
	  		    	int idd=sc.nextInt();
	  				Employee emp2=em.find(Employee.class, idd);
	  				Project proj2= em.find(Project.class, emp2.getProj().getPid());
	  				System.out.println("enter project name\t");
	  		    	String pname1=sc.next();
	  		    	System.out.println("enter employee name\t");
	  		    	String ename1=sc.next();
	  		    	System.out.println("enter salary");
	  		    	double salary1=sc.nextDouble();
				  			proj2.setPname(pname1);
				  			emp2.setName(ename1);
				  			emp2.setSalary(salary1);
				  			em.persist(proj2);
					    	em.persist(emp2);
	  		       
	  			   em.getTransaction().commit(); 
	  				
	  		    	break;
	  			case 3:
	  				
	  			
	  				
	  				
	  				
	  				
	  				
	  	case 4:
	  				System.exit(0);
	  				break;
	    	
	  			 
			    
	  		}
	  }while(ch<3);
	       	
		    	
	    	
	      
		    	em.close();          
	}

}
