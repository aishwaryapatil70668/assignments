package com.cg.demobdd.test;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions()
public class TestRunner {

	
	
}
