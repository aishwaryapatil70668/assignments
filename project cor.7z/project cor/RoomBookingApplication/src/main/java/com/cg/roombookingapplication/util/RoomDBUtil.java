package com.cg.roombookingapplication.util;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.cg.roombookingapplication.dto.Room;

public class RoomDBUtil {
	public static  List<Room> roomList =new ArrayList<Room>();
}





























/*static {

		Room roomOne=new Room();
		Room roomTwo=new Room();
		Room roomThree=new Room();
		Room roomFour=new Room();
		Room roomFive=new Room();
		Room roomSix=new Room();
		Room roomSeven=new Room();


		roomOne.setNo(101);
		roomOne.setType("NonAC");
		roomOne.setPrice(new BigDecimal(4000));

		roomTwo.setNo(102);
		roomTwo.setType("AC");
		roomTwo.setPrice(new BigDecimal(5000));

		roomThree.setNo(103);
		roomThree.setType("NonAC");
		roomThree.setPrice(new BigDecimal(4000));

		roomFour.setNo(104);
		roomFour.setType("NonAC");
		roomFour.setPrice(new BigDecimal(4000));

		roomFive.setNo(105);
		roomFive.setType("AC");
		roomFive.setPrice(new BigDecimal(5000));

		roomSix.setNo(106);
		roomSix.setType("AC");
		roomSix.setPrice(new BigDecimal(5000));

		roomSeven.setNo(107);
		roomSeven.setType("AC");
		roomSeven.setPrice(new BigDecimal(5000));
		roomList.add(roomOne);
		roomList.add(roomTwo);
		roomList.add(roomThree);
		roomList.add(roomFour);
		roomList.add(roomFive);
		roomList.add(roomSix);
		roomList.add(roomSeven);

	}

 */



/*roomMap.put(1,roomOne);
	roomMap.put(2,roomTwo);
	roomMap.put(3,roomThree);
	roomMap.put(4,roomFour);
	roomMap.put(5,roomFive);
	roomMap.put(6,roomSix);
	roomMap.put(7,roomSeven);*/


//List<Room> roomList =new ArrayList<Room>(roomMap.values());




