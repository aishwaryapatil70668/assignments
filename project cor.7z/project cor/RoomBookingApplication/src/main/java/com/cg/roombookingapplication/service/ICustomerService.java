package com.cg.roombookingapplication.service;

import java.util.List;


import com.cg.roombookingapplication.dto.Customer;

public interface ICustomerService {
	public Customer addCustomer(Customer customer);
}
