package com.cg.roombookingapplication.service;

import java.util.List;

import com.cg.roombookingapplication.dto.Room;

public interface IRoomService {

	public Room addRoom(Room room);
	 List<Room> searchByRoomType(String type);
}
