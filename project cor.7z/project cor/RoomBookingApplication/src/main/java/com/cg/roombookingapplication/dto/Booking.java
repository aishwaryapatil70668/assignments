package com.cg.roombookingapplication.dto;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class Booking {
	
	private int id;
	private Date date;
	private BigDecimal totalAmount;
	private Customer customer;
	private List<Room> rooms;
	
	public Booking() {
	
	}

	public Booking(int id, Date date, BigDecimal totalAmount, Customer customer, List<Room> rooms) {
		super();
		this.id = id;
		this.date = date;
		this.totalAmount = totalAmount;
		this.customer = customer;
		this.rooms = rooms;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Room> getRoom() {
		return rooms;
	}

	public void setRoom(List<Room> rooms) {
		this.rooms = rooms;
	}

	@Override
	public String toString() {
		return "Booking details \n [id=" + id + ", date=" + date + ", totalAmount=" + totalAmount + ", customer=" + customer
				+ ", rooms=" + rooms + "]";
	}

	
	
	
}
