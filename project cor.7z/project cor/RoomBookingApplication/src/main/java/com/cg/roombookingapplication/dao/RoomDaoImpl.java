package com.cg.roombookingapplication.dao;
import java.util.ArrayList;
import java.util.List;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.util.RoomDBUtil;

public class RoomDaoImpl implements IRoomDao {
	public List<Room> findByRoomType(String Type) {
		List<Room> typeSearch=new ArrayList<Room>();
		for (Room roomType : RoomDBUtil.roomList)
		{
			if (roomType.getType().equalsIgnoreCase(Type)) {
				typeSearch.add(roomType);
				
				
			}
		}
		return typeSearch;
	}

	public Room save(Room room) {
		RoomDBUtil.roomList.add(room);
		return room;
	}
}
