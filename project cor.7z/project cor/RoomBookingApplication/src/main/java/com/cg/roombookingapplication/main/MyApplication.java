package com.cg.roombookingapplication.main;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.exception.Exceptions;
import com.cg.roombookingapplication.exception.NameException;
import com.cg.roombookingapplication.service.BookingServiceImpl;
import com.cg.roombookingapplication.service.CustomerServiceImpl;
import com.cg.roombookingapplication.service.IBookingService;
import com.cg.roombookingapplication.service.ICustomerService;
import com.cg.roombookingapplication.service.IRoomService;
import com.cg.roombookingapplication.service.RoomServiceImpl;
import com.cg.roombookingapplication.util.RoomDBUtil;

public class MyApplication {
	static ICustomerService customerService;
	static IBookingService bookingService;
	static IRoomService roomService;
	public static void main(String[] args) {
		customerService =new CustomerServiceImpl();
		bookingService = new BookingServiceImpl();
		roomService= new RoomServiceImpl();
		Customer customer=null;
		Booking book=null;
		Room room=null;
		Scanner sc=new Scanner(System.in);
		int ch;
		do {	
			printCustomer();
			System.out.println("Enter the choice");
			ch=sc.nextInt();
		switch(ch) {	
		case 1:
		System.out.println("Enter Customer details");
		System.out.println("Enter Customer id");
		int idone=sc.nextInt();
		System.out.println("Enter customer name");
		String name=sc.next();
	
		System.out.println("Enter Mobile number");
		BigInteger mobile=sc.nextBigInteger();
		
	
		System.out.println("Enter Email");
		String email=sc.next();
		System.out.println("Enter address");
		String address =sc.next();
		customer=new Customer(idone,name, mobile,email,address);
		customerService.addCustomer(customer);
	
		break;
		case 2:
			System.out.print("Add rooms to Book you want:\n");
		 	System.out.println("Enter room details");
		 	System.out.println("Enter room no");
			int no=sc.nextInt();
			System.out.println("Enter room type( Ac/NonAc )");
			String type=sc.next();
			System.out.println("Enter Price");
			BigDecimal price=sc.nextBigDecimal();
	        room=new Room(no,type,price);
	        roomService.addRoom(room);
			break;
		case 3:	
			 System.out.println("Enter Booking details");	
				System.out.println("Enter booking id");
				int id=sc.nextInt();
				System.out.println("Enter Date");
			
				 long millis=System.currentTimeMillis();  
			        java.sql.Date date=new java.sql.Date(millis);  
			        System.out.println(date);  
				System.out.println("Enter totalamount ");
				BigDecimal amount=sc.nextBigDecimal();
				
				book=new Booking(id, date, amount,customer, RoomDBUtil.roomList);
				bookingService.addBooking(book);
				break;		
	
		   
			
		case 4:
			System.out.println("enter the Booking id");
			
			int bid=sc.nextInt();
			try
			{
			Booking bookingSearchid =bookingService.searchByBookId(bid);
			System.out.println(bookingSearchid);
			}catch(Exceptions e)
			{	System.out.println(e.getMessage()+"\n");
			 break;
			}	
			break;
			
		case 5:
			System.out.println("enter Room type (AC/NonAC) ");
			String rtype=sc.next();
			List<Room> roomsType =roomService.searchByRoomType(rtype);
			for(Room roomAll: roomsType)
			{	System.out.println("Room no: "+roomAll.getNumber());
				System.out.println("Type is: "+roomAll.getType());
				System.out.println("Price is: "+roomAll.getPrice()+"\n");
			}			
			break;
			}
		}while(ch<6);	
	}
	private static void printCustomer() {
		System.out.println("1.Add Customer");
		System.out.println("2.Add Room");
		System.out.println("3.Add Booking");
		System.out.println("4.search by Id");
		System.out.println("5.search by Room Type (AC/NonAC)\n");	
	}	
}
/*
List<Customer> customerList=customerService.showall();
for(Customer customerData: customerList)
		{	System.out.println("customer name is = "+customerData.getName());
			System.out.println("mobile number is = "+customerData.getMobileNo());
			System.out.println("email is = "+customerData.getEmail());
			System.out.println("address is = "+customerData.getAddress());
		}
break;
*/
//System.out.println("Enter room no");int rNo=sc.nextInt(); if(room.getNo()==rNo)room.setNo(rNo);