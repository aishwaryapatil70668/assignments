package com.cg.roombookingapplication.service;
import java.util.List;
import com.cg.roombookingapplication.dao.CustomerDaoImpl;
import com.cg.roombookingapplication.dao.ICustomerDao;
import com.cg.roombookingapplication.dto.Customer;
public class CustomerServiceImpl implements ICustomerService {
	ICustomerDao customerDao;
	public CustomerServiceImpl() {
		customerDao =new CustomerDaoImpl();
}
	public Customer addCustomer(Customer customer) {
		return customerDao.save(customer);
	}
}
