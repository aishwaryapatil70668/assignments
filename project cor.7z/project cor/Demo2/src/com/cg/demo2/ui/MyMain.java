package com.cg.demo2.ui;

import java.util.Scanner;

import com.cg.demo2.dto.Account;
import com.cg.demo2.dto.User;

public class MyMain {
	
	final int a=10;
	
	
	public static void main(String[] args) {

		int a = 20;
		User u=new User();
	//	User u1=new User();
		Account acc=new Account();
	//	Account acc1=new Account();
		
	//	final int a=13;
		System.out.println(a);
		
		int ch,idd;
		do
		{ 
			Scanner sc=new Scanner(System.in);
			System.out.println();
			System.out.println("select choice");
			System.out.println("1.enter no. of user \n 2.Exit");
			System.out.print("enter choice");
			ch=sc.nextInt();
			System.out.println();
			switch(ch)
			{
			case 1:
					
				System.out.println("enter user id");
				idd=sc.nextInt();
				
				System.out.println("enter name");
				String n=sc.next();
				System.out.println("enter address");
				String add=sc.next();
				
				
				System.out.println("enter aacount id");
				int aid=sc.nextInt();
				
				System.out.println("enter balance");
				double bal=sc.nextDouble();
				
				u.setAcc(acc);
				
				u.setId(idd);
				u.setAdd(add);
				u.setName(n);
				acc.setAccId(aid);
				acc.setBalance(bal);
				
				System.out.println(u);
				break;
			
			case 2:
				System.exit(0);
				break;
			}
			
		
			
			
		}while(ch<3);
		
	
	
		
		
		
		
		
		/*u.setId(1);
		u.setName("aish");
		u.setAdd("pune");
		
		
		u1.setId(2);
		u1.setName("SONAL");
		u1.setAdd("Mumbai");
		
		u.setAcc(acc);
		u1.setAcc(acc1);
		
		acc.setAccId(1212);
		acc.setBalance(1000000);
		
		acc1.setAccId(1200);
		acc1.setBalance(1034000);
		*/
	//	System.out.println("user name=\t"+u.getName());
		//System.out.println("account id=\t"+u.getAcc().getAccId());
		//System.out.println("balance=\t"+u.getAcc().getBalance());
		//System.out.println();
		
	//	System.out.println("user name=\t"+u1.getName());
	//	System.out.println("account id=\t"+u1.getAcc().getAccId());
	//	System.out.println("balance=\t"+u1.getAcc().getBalance());
		
		
	}

}
