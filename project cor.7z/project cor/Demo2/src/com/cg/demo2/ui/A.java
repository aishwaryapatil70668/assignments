package com.cg.demo2.ui;

public class A implements C {

	@Override
	public void getd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	static void getstat()
	{
		System.out.println("in static c class");
	}
	
	
}
