package com.cg.demo2.dto;

public class Account {
	
	private int AccId;
	private double balance;
	
	public int getAccId() {
		return AccId;
	}
	public void setAccId(int accId) {
		AccId = accId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [AccId=" + AccId + ", balance=" + balance + "]";
	}

}
