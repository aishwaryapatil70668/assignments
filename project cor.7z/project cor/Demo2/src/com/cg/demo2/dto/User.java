package com.cg.demo2.dto;


public class User {
	private int Id;
	private String Name;
	private String add;
	private Account acc;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public Account getAcc() {
		return acc;
	}
	public void setAcc(Account acc) {
		this.acc = acc;
	}
	
	@Override
	public String toString() {
		return "User [Id=" + Id + ", Name=" + Name + ", add=" + add + ", acc=" + acc + "]";
	}
}
