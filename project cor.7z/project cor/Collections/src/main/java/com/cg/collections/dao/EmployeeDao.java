package com.cg.collections.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.collections.dto.Employee;
import com.cg.collections.exception.EmployeeExe;
import com.cg.collections.util.DButil;


public class EmployeeDao implements EmployeeDaoo{

	public Employee save(Employee emp) {
		
		Connection con=DButil.getConnection();
		String query1="INSERT INTO EMP VALUE(?,?,?)";
		PreparedStatement pst=null;
		try {
			pst=con.prepareStatement(query1);
			pst.setInt(1, emp.getId());
			pst.setString(2, emp.getName());
			pst.setDouble(3, emp.getSalary());
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
		}
		
		return null;
	}

	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee findById(int id) throws EmployeeExe {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> showall()  {
		// TODO Auto-generated method stub
		
		Connection con=DButil.getConnection();
		String query1="SELECT EmployeeID,NAME,SALARY FROM EMP";
		PreparedStatement p=null;
		List<Employee> list=new ArrayList<Employee>();
		try {
			p= con.prepareStatement(query1);
		
		ResultSet rs=p.executeQuery();
		
		while(rs.next())
		{
			Employee emp=new Employee();
			emp.setId(rs.getInt("EmployeeID"));
			emp.setName(rs.getString("NAME"));
			emp.setSalary(rs.getDouble("SALARY"));
			list.add(emp);
		}
		
		}catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("select not working");
		}finally {
			try {
				p.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
		}
		
	
		
	
	return list;
	}	
}

	/*List<Employee> empdata;
	public EmployeeDao()
	{
		empdata=new ArrayList<Employee>();
	}
	
	
	
	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		
	
		empdata.add(emp);
		return emp;
	}

	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		
		List<Employee> empsearch=new ArrayList<Employee>();
		for (Employee empp : empdata) {
	        if (empp.getName().equals(name)) {
	           empsearch.add(empp);
	        }
	    }
		return empsearch;
	}

	public Employee findById(int id) throws EmployeeExe {
		
		
	
		for (Employee employee : empdata) {
	     
			if (employee.getId()==id)
		{
	           return employee;
	    }else
	    {
	    	
	    	throw new EmployeeExe("id not found");
	    }
	        
	
		}
		return null;
		
	}

	public List<Employee> showall() {
		// TODO Auto-generated method stub
		return empdata;
	}
	
	*/


