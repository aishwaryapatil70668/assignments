package com.cg.collections.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.collections.dao.EmployeeDao;
import com.cg.collections.dao.EmployeeDaoo;
import com.cg.collections.dto.Employee;
import com.cg.collections.exception.EmployeeExe;

public class EmployeeServiceImpl implements EmployeeService{

	
	
	EmployeeDaoo dao;
	
	public EmployeeServiceImpl()
	{
		dao=new EmployeeDao();
	}
	
	
	public void addemp(Employee emp) {

		dao.save(emp);
	}

	public List<Employee> searchName(String Name) {
		
		
		// TODO Auto-generated method stub
		return dao.findByName(Name);
	}

	public List<Employee> showall() {
		// TODO Auto-generated method stub
		return dao.showall();
	}

	public Employee update(Employee emp) throws EmployeeExe {
		// TODO Auto-generated method stub
		
		
		return null;
		
	}
		

		public void sort() {
			// TODO Auto-generated method stub
			
		}
		public Employee searchid(int id) {
			// TODO Auto-generated method stub
			return dao.findById(id);
		}



		

}
