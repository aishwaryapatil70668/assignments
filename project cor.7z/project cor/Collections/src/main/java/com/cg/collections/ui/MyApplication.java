package com.cg.collections.ui;


	/*import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

	public class MyApplication {

		public static void main(String[] args) {
		
			
			
			try {
				String driver=null ,url=null,uname=null,pass=null;
		try {
			InputStream it =new FileInputStream("resources/jdbc.properties");
			Properties ps=new Properties();
			ps.load(it);
			driver=ps.getProperty("jdbc.driver");
			url=ps.getProperty("jdbc:mysql://localhost/test\", \"root\", \"Capgemini123");
			uname=ps.getProperty("root");
			pass=ps.getProperty("Capgemini123");
			
			
			
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		} catch (IOException e) {
			
			
			e.printStackTrace();
		}
		Class.forName(driver);

	Connection con=	DriverManager.getConnection(url,uname,pass);
	Scanner s=new Scanner(System.in);

	PreparedStatement pst=con.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
	
	
	System.out.println("enter id");
	int id=s.nextInt();
	System.out.println("enter name");
	String name=s.next();

	System.out.println("enter sal");
	double sal=s.nextDouble();


	pst.setInt(1, id);
	pst.setString(2, name);
	pst.setDouble(3, sal);
	pst.executeUpdate();
	System.out.println("update salary");
PreparedStatement pstt=con.prepareStatement("UPDATE EMPLOYEE  SET SALARY = ? WHERE ID = ? ");
	
	System.out.println("enter id");
	int id1=s.nextInt();
	
	System.out.println("enter sal");
	double sal1=s.nextDouble();
	
	pstt.setDouble(1, sal1);
	pstt.setInt(2, id1);
	pstt.executeUpdate();
	System.out.println("Record is updated!");
	
	
	
	System.out.println("Delete record");
	
PreparedStatement pst2=con.prepareStatement("DELETE FROM EMPLOYEE WHERE ID = ? ");
	
	System.out.println("enter id");
	int id2=s.nextInt();
	
	
	pst2.setInt(1, id2);
	pst2.executeUpdate();
	System.out.println("Record is deleted!");
	

	System.out.println("conncetion done");
		} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
			System.out.println("driver not loaded");
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("conncetion not done");
			} 

		}

	}
*/