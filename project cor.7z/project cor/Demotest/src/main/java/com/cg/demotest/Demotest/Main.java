package com.cg.demotest.Demotest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InputStream fread=null;
		OutputStream fwrite=null;
		try {
				
			fread=new FileInputStream("my.txt");
			fwrite=new FileOutputStream("mywrite.txt");
			int data=0;
			while( (data = fread.read())>=0)
			{
				fwrite.write(data);
				
					/*System.out.println(data);
	
					char c=(char)data;
					System.out.println(c);*/
			}
				
		//System.out.println(data);
			
		}catch (FileNotFoundException e) {
			
			System.out.println("file not found");
		} catch (IOException e) {
			System.out.println("file not read");
			
		}finally
		{
			try {
				fread.close();
				fwrite.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("file not close");
			}
			
			
		}
		
	}

}
