package com.cg.maventwo.test;

import org.junit.Test;

public class MyTest {

	@Test
	public void test() {
		System.out.println("test");
	}

}
