package com.cg.Serial.Serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class Myserial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp=new Employee(1,"asa",100.0);
		try {
			OutputStream fwrite =new FileOutputStream("D:/mywr.txt");
			ObjectOutput obwrite=new ObjectOutputStream(fwrite);
			obwrite.writeObject(emp);
			obwrite.flush();
			obwrite.close();		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		
		Employee eread=null;
		
		try {
			InputStream fread=new FileInputStream("D:/mywr.txt");
			ObjectInput obread=new ObjectInputStream(fread);
			
			eread=(Employee) obread.readObject();
			obread.close();
			System.out.println(eread);
			
		} catch (FileNotFoundException e) {
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
