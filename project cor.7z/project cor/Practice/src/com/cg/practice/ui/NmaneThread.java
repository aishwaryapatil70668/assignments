package com.cg.practice.ui;

public class NmaneThread implements Runnable{

	String name;
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
	System.out.println("thread is running");
		System.out.println("run by "+Thread.currentThread().getName());
		
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 NmaneThread n=new  NmaneThread();
		 Thread t=new Thread(n);
		 System.out.println("run by "+Thread.currentThread().getName());
		 t.setName("first");
		 t.start();
		
		
		
	}



}
