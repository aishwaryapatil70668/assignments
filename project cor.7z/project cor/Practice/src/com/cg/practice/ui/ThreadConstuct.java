package com.cg.practice.ui;

public class ThreadConstuct extends Thread{

	private String name;
	private int delay;
	
	public ThreadConstuct() {
	
	}
	public ThreadConstuct(String name, int id) {
		super(name);
	//	this.name=name;
		this.delay = delay;
	}

public void run()
{
	//for(int i=0;i<6;i++)
		
	System.out.println( getName() +" Thread is Running"); 
    try 
    { 
             sleep(delay); //put thread to sleep 
    } 
             
    catch(InterruptedException e) 
    {
    	e.printStackTrace();
    	
    }
	System.out.println( getName() +" Thread is finished"); 
}

public static void main(String[] args) {
		// TODO Auto-generated method stub
	ThreadConstuct tc= new ThreadConstuct("first",10);
	ThreadConstuct tc1= new ThreadConstuct("second",20);
	ThreadConstuct tc2= new ThreadConstuct("third",5000);
	
	
	tc.start();
	tc1.start();
	tc2.start();
	
	
	}

}
