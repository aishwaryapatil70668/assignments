package com.cg.practice.ui;

	class MyThread extends Thread 
	{
	 public static void main(String [] args) {
//	MyThread t = new MyThread();
	//Thread x = new Thread(t);
	   (new MyThread()).start();  
	
	// t.start();
		}
	public void run() {
		 for(int i=0;i<3;++i) {
	 System.out.print(i + "..");
		 }
		}
 }
	/*public void run(){  
		System.out.println("thread is running...");  
		}  
	
	
	
	public static void main(String[] args) {
		 ByExtendingThread t1=new  ByExtendingThread();		
		 t1.start();
	}
*/

/* By extending thread class
1) The class should extend Java Thread class.
2) The class should override the run() method.
3) The functionality that is expected by the Thread to be executed is written in the run() method.

void start(): Creates a new thread and makes it runnable.

void run(): The new thread begins its life inside this method.*/