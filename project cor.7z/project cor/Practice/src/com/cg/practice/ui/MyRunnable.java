package com.cg.practice.ui;

public class MyRunnable implements Runnable {

public static void main(String[] args) {
// TODO Auto-generated method stub


Thread thread1 = new Thread(new MyRunnable(), "First");
        Thread thread2 = new Thread(new MyRunnable(), "Second");
        Thread thread3 = new Thread(new MyRunnable(), "Third");
  
        System.out.println("thread 1 before start "+thread1.getState());
        System.out.println("thread 2 before start "+thread2.getState());
        System.out.println("thread 2 before start "+thread3.getState());
       thread2.start();
        thread1.start();
      
        System.out.println("thread 1 after start "+thread1.getState());
        System.out.println("thread 2  after start of thread 1 "+thread2.getState());
        System.out.println("thread 3 after start of thread 1 "+thread3.getState());
        //start second thread after waiting for 10 seconds or if it's dead
        try {
        	
        	
            thread1.join(10000);
            thread2.join();
            System.out.println("thread 1 after join of 1 "+thread1.getState());
            System.out.println("thread 2 after join of 1"+thread2.getState());
            System.out.println("thread 3 after join of 1 "+thread3.getState());
            System.out.println(Thread.currentThread().getState());
        } catch (InterruptedException exp) {
           System.err.println(exp.getMessage());
        }

   //     thread2.start();
        System.out.println("thread 2 start");
        System.out.println("thread 1 after start of 2 "+thread1.getState());
        System.out.println("thread 2 after start of 2"+thread2.getState());
        System.out.println("thread 3 after start of 2"+thread3.getState());
        //start third thread only when first thread is dead
        try {
        	 System.out.println(Thread.currentThread().getState());
            thread1.join();
            System.out.println("thread 1 after join of 1 "+thread1.getState());
            System.out.println("thread 2 after join of 1 "+thread2.getState());
            System.out.println("thread 3 after join of 1 "+thread3.getState());
            
        } catch (InterruptedException exp) {
            System.err.println(exp.getMessage());
        }
         
        thread3.start();
        System.out.println("thread 1 after start "+thread1.getState());
        System.out.println("thread 1 after start "+thread2.getState());
        System.out.println(thread3.getState());

//let all threads finish execution before finishing main thread
        try {
            thread1.join();
            System.out.println(thread1.getState());
            thread2.join();
            System.out.println(thread2.getState());
            thread3.join();
            System.out.println(thread3.getState());           
          
            System.out.println(thread1.getState());
            System.out.println(thread2.getState());
            System.out.println(thread3.getState());
            System.out.println(Thread.currentThread().getState());
        } catch (InterruptedException exp) {
           
	 System.err.println(exp.getMessage());
        }
        System.out.println(thread1.getState());
        System.out.println(thread2.getState());
        System.out.println(thread3.getState());
        System.out.println("All threads are dead, exiting main thread");
        System.out.println(thread1.getState());
        System.out.println(thread2.getState());
        System.out.println(thread3.getState());
   }

@Override
public void run() {
	// TODO Auto-generated method stub
	System.out.println("hiee   "+Thread.currentThread().getName());
	 System.out.println(Thread.currentThread().getState());
}

}
