package com.cg.practice.ui;



	class MyApplication extends Exception {}
	class Derived extends MyApplication  {}
	public class MyApplication {
	   public static void main(String args[]) 
	    {
	    
	    try {
	        
	        throw new Derived();
	     }
	     catch(MyApplication b)     
	     { 
	        System.out.println("Caught base class exception"); 
	     }
	     catch(Derived d)  
	    { 
	        System.out.println("Caught derived class exception"); 
	     }
	   }
	 } 