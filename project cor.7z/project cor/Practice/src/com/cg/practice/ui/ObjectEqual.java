package com.cg.practice.ui;

public class ObjectEqual {

	    public static void main(String[] args) 
	   
	    
	    { 
	        String s1 = new String("HELLO"); 
	        String s2 = new String("HELLO"); 
	      //  System.out.println(s1.hashCode());
	      //  System.out.println(s2.hashCode());
	     System.out.println(s1 == s2); 
	        
	        System.out.println(s1.equals(s2)); 
	        
	        System.out.println(s1);
	        
	        String str=new String ("abc");
	        str.concat("Sol");
	        System.out.println( "string mutable = " +str );
	        
	        
	        StringBuffer Sb= new StringBuffer ("Tec");
	        Sb.append("Sol");
	        System.out.println( Sb );
	        
	        
	        
	    } 
	} 