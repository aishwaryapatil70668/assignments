package com.cg.practice.ui;

import java.lang.StringBuffer;

class SyncTest implements Runnable {
	    StringBuffer str;
	    SyncTest(StringBuffer s) {
	        this.str = s;
	    }
	    
	    public void run() {
	        synchronized (this) {
	            for (int i = 0; i < 100; i++)
	                System.out.println(str);
	            str.setCharAt(0, (char) (str.charAt(0)+1));
	        }
	         
	    }
	    public static void main (String [] args)
	    {
	        StringBuffer s = new StringBuffer("A");
	        SyncTest st = new SyncTest (s);
	        Thread one = new Thread(st);
	        Thread two = new Thread(st);
	        Thread three = new Thread(st);
	        one.start(); two.start(); three.start();
	    }
	}
