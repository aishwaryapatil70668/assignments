package com.cg.practice.ui;
public class Math {
	
		MathEqu[] 	m=new MathEqu[3];
		m[0]= new MathEqu('a',10.1d,20.3d);
		m[1]= new MathEqu('b',10.1d,20.3d);
		m[2]= new MathEqu('c',10.1d,20.3d);

		for(MathEqu e:m) {
			
			e.exe();
			
			System.out.println("result="+e.getRes());
			
		}
		
		double ld=20.3d;
		double rd=2.4d;
		
		int ldd=2;
		int rdd=3;
		MathEqu ov=new MathEqu('a');
		
		ov.exe(ld,rd);
		
		System.out.println("ovl double"+ov.getRes());
		
ov.exe(ldd,rdd);
		
		System.out.println(ov.getRes());
		
	}

}
