package com.cg.practice.ui;

public class ByThreadConst  extends Thread{

	
	    private String to;

	  
	    public ByThreadConst() {
			
		}

		public ByThreadConst(String to) {
		//	super(to);
			this.to = to;
		}

		@Override
	    public void run() {
	        System.out.println("hello " + to);
	    }
	

	public static void main(String[] args) {
	    new ByThreadConst("world!").start();
	}
}