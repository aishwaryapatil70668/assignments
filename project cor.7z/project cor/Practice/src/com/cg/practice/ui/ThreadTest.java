package com.cg.practice.ui;

import java.lang.*; 

//MyThread extending Thread 

public class ThreadTest extends Thread 
{ 
    public void run() 
    { 
        System.out.println("In run"); 
       yield(); 
        
    } 
    public static void main(String []argv) 
    { 
    	 
        (new ThreadTest()).start(); 
        System.out.println("Leaving run"); 
      
    } 
} 