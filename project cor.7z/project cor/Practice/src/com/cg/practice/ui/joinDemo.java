package com.cg.practice.ui;

public class joinDemo implements Runnable{

	 
	
	static void dostuff()  {
		
		for(int i=0;i<5;i++)
		System.out.println("a is ruunning");
		
		
}

	static void doother() {
		
		for(int i=0;i<5;i++)
		System.out.println("b is running");
		
}
		public void run() 
		 { 
			System.out.println(Thread.currentThread().getName());
		 } 
		public static void main(String[]args) throws InterruptedException 
		 {
			joinDemo j=new joinDemo();
			
			Thread t = new Thread(j);
			Thread t2 = new Thread(j);
			
		
		
			t.start();
			
			t.join();
			
		 }
}
