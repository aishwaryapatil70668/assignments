package com.cg.practice.ui;

public class DudesChat  implements Runnable {
	
		  static Dudes d;
		  public static void main(String[] args)
		  {
		  new DudesChat().go();
		  }
		  void go() {
		  d = new Dudes();
		  new Thread(new DudesChat()).start();
		  
		  new Thread(new DudesChat()).start();
		  }
		  public void run() {
			  System.out.println("run"+Thread.currentThread().getName());
			  System.out.println(Thread.currentThread().getId());
		  d.chat(Thread.currentThread().getId());
		}
}
		
			 class Dudes {
				 static long flag = 0;
			// synchronized void chat(long id) {
				 void chat(long id) {
					  System.out.println("chat"+Thread.currentThread().getName());
					  System.out.println(Thread.currentThread().getId());
				// insert code here
				if(flag == 0) flag = id;
				 for(int x = 1; x < 3; x++) {
					  System.out.println("for"+Thread.currentThread().getName());
					  System.out.println(Thread.currentThread().getId());
				 if(flag == id) System.out.print("yo ");
				 else System.out.print("dude ");
				  }
				  }
				  
				
}





		/*static Thread laurel, hardy;
		
		public static void main(String[] args) {
		
		laurel = new Thread() 
		{
		
		public  void run() {
			System.out.println("A");
		try {
			
			//System.out.println(Thread.currentThread().getName());
			hardy.sleep(10);
		//	System.out.println(Thread.currentThread().getName());
		} 
		catch (Exception e) {
		System.out.println("B");
		}
		System.out.println("C");
		}
	};
		hardy = new Thread() {

		public  void run() {
		System.out.println("D");
		synchronized(hardy)
		{
		try {
			
		hardy.wait();
		//System.out.println(Thread.currentThread().getName());
		} catch (Exception e) {
		System.out.println("E");
		}
		System.out.println("F");
		}
	
		}	
		
		};
		laurel.start();
		hardy.start();
		}
		}
	
	
	
	*/
	
	
	
	

	/*public static void main (String [] args) {
	Thread t = new MyThread1() {
	public void run() {
	System.out.print("foo ");
	}
};
	t.start();
	} 
	
}
class MyThread1 extends Thread {
	MyThread1() {
		System.out.print("MyThread ");
		}
		public void run() {
		System.out.print("bar ");
		}
		public void run(String s) {
		System.out.print("baz ");
		}
		}
	*/
		
	/*public static synchronized void main(String[] args) throws InterruptedException {
		Thread t = new Thread();
	//	Thread t1 = new Thread();
		t.start();
//		t1.start();
		System.out.print("X");//main thread execute not t
		synchronized(t)
		{
			System.out.println(Thread.currentThread().getName());
			t.wait(10000);
			t.notify();
			System.out.println(t.getState());
		}
		
		System.out.print("Y"+t.getState());
	}
}*/
	
	/*private StringBuilder contents = new StringBuilder();
	public void log(String message) {
	contents.append(System.currentTimeMillis());
	contents.append(": ");
	contents.append(Thread.currentThread().getName());
	contents.append(message);
	contents.append("\n");
	}

	public String getContents() { 
		
		return contents.toString(); 
		}
	
	public static void main(String [] args) {
		Test t=new Test();
		t.log("aish");
		t.getContents();
		
		
		
	}	*/

	//	Test t=new Test();
		
	/*public static void main(String [] args) {
		Test t=new Test();
		
	System.out.print("1 ");
		synchronized(t){
	 System.out.print("2 ");
		 
		 try {
		t.wait(2000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
	 
	
		 }
		 System.out.print("3 ");
		 }
		 }*/