package com.cg.practice.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class Emu
{
	static class PowerOutage extends Exception {}
	static class Thunderstorm extends Exception {}
public static void main(String[] args)
{
	
		
		
		try {
		new Emu().listen();
		System.out.println("a");
		} catch(PowerOutage | Thunderstorm e) {
		e = new PowerOutage();
		System.out.println("b");
		} finally { System.out.println("c"); }
		}
		public void listen() throws PowerOutage, Thunderstorm{ }
}
}
/*TreeSet<String> s = new TreeSet<String>();
 TreeSet<String> subs = new TreeSet<String>();
s.add("a"); 
s.add("b");
s.add("c");
s.add("d");
s.add("e");

subs = (TreeSet)s.subSet("b", true, "d", true);
System.out.println("subset "+subs);
s.add("g");
System.out.println(s);

 s.pollFirst();
 System.out.println("after poll"+s);
 s.pollFirst();
 System.out.println("after a poll"+s);
 s.add("c2");
 System.out.println(s);
System.out.println(s.size() +" "+ subs.size());*/
}



/*
public class Emu
{
public static void before()

{
		Set set = new TreeSet();
		set.add("2");
		set.add(3);
		set.add("1");
		
		Iterator it = set.iterator();
		
		while (it.hasNext())
		
			System.out.print(it.next() + " ");
}

public static void main(String[] args)
{
	
	before();
	
	
}
}


*/






/*class Emu
{
	static String s = "-";
	void s1() 
	{		try { 
					s2(); 
				}
			catch (Exception e)
			{
				s += "c";
			}	
	}
void s2() throws Exception 
{
		s3(); 
		s += "2";
		s3(); 
		s += "2b";
}
void s3() throws Exception
{
	throw new Exception();
}
	
public static void main(String[] args)
	{
				new Emu().s1();
				System.out.println(s);
	}
			
}


class Emu {
	
static String s = "-";

public static void main(String[] args) {
	
	try {
			throw new Exception();
		}catch (Exception e) 
			{	
				try
				{			try
							{
							throw new Exception();
							}
							catch (Exception ex) 
							{
								s += "ic "; 
							}
					throw new Exception(); 
				}
				catch (Exception x)
				{ 
					s += "mc "; 
				}
				finally 
				{
					s += "mf ";
				}
			}
		finally 
		{
			s += "of "; 
		}
		System.out.println(s);
		} 
	*/
