package com.cg.practice.ui;

public class MathEqu {

	private double lval;
	private double rval;
	private double res;
	private char  op='a';
	
	public double getLval() {
		return lval;
	}

	public void setLval(double lval) {
		this.lval = lval;
	}
	public double getRval() {
		return rval;
	}
	public void setRval(double rval) {
		this.rval = rval;
	}

	public double getRes() {
		return res;
	}

public void setRes(double res) {
		this.res = res;
	}
public char getOp() {
		return op;
	}
public void setOp(char op) {
		this.op = op;
	}


public MathEqu()
{
}

public MathEqu(char op) {

	this.op = op;
}

public MathEqu(char op,double lval, double rval ) {
	
	this(op);
	this.lval = lval;
	this.rval = rval;
	
}

public void exe(double lval,double rval)
	{
	this.lval = lval;
	this.rval = rval;
	
	exe();
	}




	public void exe()
	{
		switch(op) {
		
		case 'a': res=lval+rval;
		break;
		case 'b': res=lval-rval;
		break;
		case 'c': res=lval*rval;
		break;
		
		default:System.out.println("error");
		}
		
	}
}
