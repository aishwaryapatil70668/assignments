package com.cg.practice.ui;

public class RunnableInterface implements Runnable{

	//Runnable interface have only one method named run().
	
	public void run(){  
		System.out.println("thread is running...");  
		}  
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunnableInterface runn=new RunnableInterface();
		Thread t=new Thread(runn);
		t.start();
		
		
	//If you are not extending the Thread class,your class object would not be treated as a thread object.
	//So you need to explicitly create Thread class object.
//We are passing the object of your class that implements Runnable so that 
		//your class run() method may execute.
	}

}
