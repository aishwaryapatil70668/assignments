package com.cg.demo1.ui;



import java.util.Scanner;

import com.cg.demo1.dto.Employee;
import com.cg.demo1.dto.Project;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("hello world...."+args[0]+"\n"+args[1]);
	//	System.out.println("Welcome...."+args[1]);
		
	//	Employee emp1=new Employee();
		
		
	/*	Project p=new Project();
		p.setProject(2313);
		p.setProjectName("student management");
        p.setProjectDesc("student info");
        p.setCost(127000);
        System.out.println(p);
      */ 
        /*
        System.out.println(p.getProject());
        System.out.println(p.getProjectName());
        System.out.println(p.getProjectDesc());
        System.out.println(p.getCost());
        
        */
		
		
		Employee emp=new Employee();
//		Employee emp1=new Employee();
		
		
	Project proj=new Project();
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter id\t");
	int id=sc.nextInt();
	//System.out.println("id is \t"+id);
	
	
	System.out.println("enter name\t");
	String ename=sc.next();
//	System.out.println("name is\t"+ename);
	
	
	
	System.out.println("enter Designation");
	String desgg=sc.next();
	
	System.out.println("enter salary");
	double salary=sc.nextDouble();
	
	
	System.out.println("enter project id\t");
	int idd=sc.nextInt();
	
	System.out.println("enter project name\t");
	String pname=sc.next();
	
	System.out.println("enter project description\t");
	String pdesc=sc.next();
	
	System.out.println("enter cost");
	double cost=sc.nextDouble();

	emp.setProj(proj);
	
	emp.setEmpId(id);
	emp.setEmpName(ename);
	emp.setEmpSalary(salary);
	emp.setEmpDeg(desgg);
	
	proj.setProject(idd);
	proj.setProjectName(pname);
	proj.setProjectDesc(pdesc);
	proj.setCost(cost);
	
	System.out.println(emp);
		
		
		
		
		
		
		/*
		int id=Integer.parseInt(args[0]);
		String namee=args[1];
		double sal=Double.parseDouble(args[2]);
		String desg=args[3];
		
		
		emp.setEmpId(id);
		emp.setEmpName(namee);
		emp.setEmpSalary(sal);
		emp.setEmpDeg(desg);
		
		int projId=Integer.parseInt(args[4]);
		String projName=args[5];
		String pdesc=args[6];
		double pcost=Double.parseDouble(args[7]);
		
	
	emp1.setEmpId(2);
		emp1.setEmpName("aishwarya");
		emp1.setEmpSalary(10000023);
		emp1.setEmpDeg("engineerr");
	
		emp.getProj().setProject(10);
		emp.getProj().setProjectName("hotel mamangement");
		emp.getProj().setProjectDesc("hotel");
		emp.getProj().setCost(1000); //getter for project
		
		
		emp.setProj(proj);
		emp1.setProj(proj);
		
		proj.setProject(projId);
		proj.setProjectName(projName);
		proj.setProjectDesc(pdesc);
		proj.setCost(pcost);
		
		
		 //printing emp and proj data
	//	System.out.println(emp1);
		
		//System.out.println(emp.getProj());//printing only proj data
	//	System.out.println("project id is\t"+emp.getProj().getProject());//printing only project id 
				
		
	
		
		/*
		System.out.println(emp.getEmpId());
		System.out.println(emp.getEmpName());
		System.out.println(emp.getEmpSalary());
		System.out.println(emp.getEmpDeg());
*/
		
		
		
		
		
		
	//	emp.getLogin();
		//emp.getLogout();
		
	}

}
