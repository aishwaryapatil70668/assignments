package com.cg.demo1.dto;

public class Employee {
	
	private int empId;
	private String empName;
	private double empSalary;
	private String empDeg;
	private Project proj;
	
	public Employee()
	{
		
	}
	public Employee(int empId, String empName, double empSalary, String empDeg, Project proj) {
	//	super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDeg = empDeg;
		this.proj = proj;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpDeg() {
		return empDeg;
	}
	public void setEmpDeg(String empDeg) {
		this.empDeg = empDeg;
	}
	public Project getProj() {
		return proj;
	}
	public void setProj(Project proj) {
		this.proj = proj;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDeg=" + empDeg
				+ ", proj=" + proj + "]";
	}
	









	/*	
	public Employee()
	{
		System.out.println("In constructor");
	//	System.out.println("id="+empId);
	}

	public Employee(int empw,String empName,double empSalary,float no,boolean b) {
		
		this.empId=empId;
		this.empName=empName;
		this.empSalary=empSalary;
		this.no=no;
		this.b=b;
		
	}
	
	public void getLogin()
	{
		
		System.out.println("in get login...");
		
		System.out.println("emp id \t" +this.empId);
		System.out.println("emp name \t" +this.empName);
		System.out.println("emp sal \t" +this.empSalary);
		System.out.println("emp sal \t" +this.no);
		System.out.println("emp sal \t" +this.b);
	}
	
	public void getLogout() {
		
		System.out.println("in get logout....");
		
	}
	*/



}
