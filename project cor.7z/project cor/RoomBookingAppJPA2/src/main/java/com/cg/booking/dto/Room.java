package com.cg.booking.dto;


import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Room {

	@Id
	@Column(name="roomid")
	private int id;
	private int number;
	private String type;
	private BigDecimal price;
	
	

	
	public Room() {
		
	}
	
public Room(int id, int number, String type, BigDecimal price) {
		super();
		this.id = id;
		this.number = number;
		this.type = type;
		this.price = price;
		
	}



	/*	public Room(int id,int number, String type, BigDecimal price) {
		super();
		this.id = id;
		this.number = number;
		this.type = type;
		this.price = price;
	}
*/
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Room [id=" + id + ", number=" + number + ", type=" + type + ", price=" + price + "]";
	}

	
	

	
	
	
	
}