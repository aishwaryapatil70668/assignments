package com.cg.booking.main;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.cg.booking.dto.Booking;
import com.cg.booking.dto.Customer;
import com.cg.booking.dto.Room;
import com.cg.booking.exception.Exceptions;
import com.cg.booking.service.BookingServiceImpl;
import com.cg.booking.service.CustomerServiceImpl;
import com.cg.booking.service.IBookingService;
import com.cg.booking.service.ICustomerService;

public class MyApplication {
	static ICustomerService customerService;
	static IBookingService bookingService;

	public static void main(String[] args) 
	{
		customerService =new CustomerServiceImpl();
		bookingService = new BookingServiceImpl();
	
		Customer customer=null;
		Booking book=null;
		Room room = null;
		
		List<Room> roomList;
		int idroom=0;
		int no=0;
		String type=null;
		BigDecimal price=null;
		int idone=0;
		int ans;
		Scanner sc=new Scanner(System.in);
		int ch;
		do {	
			printCustomer();
			System.out.println("Enter the choice");
			ch=sc.nextInt();
		switch(ch) {	
		
		case 1:
		System.out.println("Enter Customer details"); //Adding customer details
		System.out.println("Enter customer id");
		idone=sc.nextInt();
		System.out.println("Enter customer name");
		String name=sc.next();
	
		System.out.println("Enter Mobile number");
		BigInteger mobile=sc.nextBigInteger();
		
		System.out.println("Enter Email");
		String email=sc.next();
		System.out.println("Enter address");
		String address =sc.next();
		customer=new Customer(idone,name, mobile,email,address);
		customerService.addCustomer(customer);
		System.out.println("\n customer added \n");
	
		break;
	
		case 2:
			
			System.out.println("Enter Booking details");	//Adding booking details
			System.out.println("Enter booking id");
			int id=sc.nextInt();
			System.out.println("Enter Date");
			long millis=System.currentTimeMillis();  
		    java.sql.Date date=new java.sql.Date(millis);  
		    System.out.println(date);  
			System.out.println("Enter totalamount ");
			BigDecimal amount=sc.nextBigDecimal();
			
			roomList=new ArrayList<Room>();
			
				do {
				
					System.out.println("Enter room details");
				 	System.out.println("Enter room id");
				 	idroom=sc.nextInt();
				 	System.out.println("Enter room no");
					no=sc.nextInt();
					System.out.println("Enter room type( Ac/NonAc )");
					type=sc.next();
					System.out.println("Enter Price");
					price=sc.nextBigDecimal();
					
					room=new Room(idroom,no,type,price);
					roomList.add(room);
					System.out.println(roomList);
				System.out.println("press 1 to continue /2 to exit");
				ans=sc.nextInt();
				}while(ans!=2);
			
				System.out.println("Enter customer id");
				idone=sc.nextInt();
				customer=customerService.SearchByCustomerId(idone);
				
				try 
				{
					book=new Booking(id,date, amount,customer, roomList);
					System.out.println(book);
					bookingService.addBooking(book);
				
				} 
				catch(Exceptions e) {
					
					System.out.println(e.getMessage());
					break;
				}
				System.out.println("\n Booking done \n");
				
			
			break;		
			
		    
		case 3:
			System.out.println("enter the Booking id");
			int bid=sc.nextInt();
			try
			{
			Booking bookingSearchid =bookingService.searchByBookId(bid);
			
			System.out.println(bookingSearchid);
			}catch(Exceptions e)
			{	System.out.println(e.getMessage()+"\n");
			 break;
			}	
			break;
			
		case 4:
			
			System.out.println("enter Room type (AC/NonAC) ");
			String rtype=sc.next();
			try
			{
			List<Room> roomsType =bookingService.searchByRoomType(rtype);
			
			for(Room roomAll: roomsType)
			{	System.out.println("\n");
				System.out.println("Room no: "+roomAll.getNumber());
				System.out.println("Type is: "+roomAll.getType());
				System.out.println("Price is: "+roomAll.getPrice()+"\n");
			}
			
			}catch (Exceptions e) {
			System.out.println(e.getMessage()+" \n");
			break;
			}
			break;
			}
	
		}while(ch<7);	
	}
	private static void printCustomer() {
		System.out.println("1.Add Customer");
		System.out.println("2.Make Booking");
		System.out.println("3.search by Id");
		System.out.println("4.search by Room Type (AC/NonAC)\n");	
	}	
}
/*
SimpleDateFormat form= new SimpleDateFormat("DD-MM-YYYY");
	String sdate=form.format(new java.util.Date());
Date curr=form.parse(sdate);*/
