package com.cg.booking.exception;

import java.io.FileNotFoundException;

public class MyException extends FileNotFoundException {

	
}
