package com.cg.booking.dao;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import com.cg.booking.dto.Booking;
import com.cg.booking.dto.Customer;
import com.cg.booking.dto.Room;
import com.cg.booking.util.ConnectionDBUtil;

public class BookingDaoImpl implements IBookingDao {
	EntityManager em;

	public BookingDaoImpl() {
		em=ConnectionDBUtil.em;
	}
	public Booking save(Booking booking) {

		Customer customer=em.find(Customer.class,booking.getCustomer().getId());
		
		em.getTransaction().begin();
		em.merge(booking);
		em.getTransaction().commit();
		return booking;	 

	}
	public Booking findByBookId(int id)  {
		
		Booking  book = em.find(Booking.class, id);
		return book;

	}
	
public List<Room> findByRoomType(String Type) {

		Query query = em.createQuery("FROM Room r where r.type = :type ");
		query.setParameter("type", Type);
		List<Room> roomtype = query.getResultList();
		
		return roomtype;
	}

	
	
}
