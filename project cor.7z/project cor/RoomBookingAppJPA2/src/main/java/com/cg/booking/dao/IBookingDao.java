package com.cg.booking.dao;

import java.util.List;

import com.cg.booking.dto.Booking;
import com.cg.booking.dto.Room;

public interface IBookingDao {
	public Booking save(Booking booking); 
	public Booking findByBookId(int id);
	List <Room> findByRoomType(String Type);
}
