package com.cg.booking.dto;

	import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
	public class Booking {
		@Id
		@Column(name="bookingid")
		private int id;
		private Date date;
		private BigDecimal totalAmount;
		
		@OneToOne
		private Customer customer;
		
		@OneToMany(cascade=CascadeType.ALL)
		@JoinColumn(name="Booking_id")
		private List<Room> rooms = new ArrayList<Room>();
		
		public Booking() {
		id=0;
		}

		public Booking(int id,Date date, BigDecimal totalAmount, Customer customer, List<Room> rooms) {
			super();
			this.id = id;
			this.date = date;
			this.totalAmount = totalAmount;
			this.customer = customer;
			this.rooms = rooms;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public BigDecimal getTotalAmount() {
			return totalAmount;
		}

		public void setTotalAmount(BigDecimal totalAmount) {
			this.totalAmount = totalAmount;
		}

		public Customer getCustomer() {
			return customer;
		}

		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

		public List<Room> getRoom() {
			return rooms;
		}

		public void setRoom(List<Room> rooms) {
			this.rooms = rooms;
		}

		@Override
		public String toString() {
			return "Booking details \n[Bookingid =" + id + ", date=" + date + ", totalAmount=" + totalAmount + ",Customer Details=" + customer
					+ ",Rooms Details =" + rooms + "]";
		}

		
		
		
	
	
}
