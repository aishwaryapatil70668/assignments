package com.cg.booking.service;

import java.util.List;

import com.cg.booking.dto.Booking;
import com.cg.booking.dto.Room;

public interface IBookingService {
	public Booking addBooking(Booking booking);
	public Booking searchByBookId(int id);
	List<Room> searchByRoomType(String type);
}
