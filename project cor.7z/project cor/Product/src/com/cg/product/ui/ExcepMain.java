package com.cg.product.ui;

public class ExcepMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new Excep().alll();
		
	}

}
