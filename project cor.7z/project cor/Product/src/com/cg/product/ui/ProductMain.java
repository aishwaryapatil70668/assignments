package com.cg.product.ui;

import java.util.Scanner;

import com.cg.product.dto.Product;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product p[] =new Product[10];
		int i;
		Scanner sc=new Scanner(System.in);
		
		for(i=0;i<2;i++)
			p[i] =new Product();
	
		int ch;
		
		do
		{ 
			
			System.out.println("select your choice");
			System.out.println("1.Add product  \n 2.Show product \n 3.exit");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch) {
			case 1:
				
				for(i=0;i<2;i++)
				{
					
					p[i].add();
				}
				break;
			
			case 2:
			 
				System.out.println("product details");
				
				for (i = 0; i < 2; i++)
				{
					p[i].show();
				
				}
	
				
			 break;
				
			case 3:
				System.exit(0);
				break;
				
			}				
				
			
		}while(ch<3);
	}
	}