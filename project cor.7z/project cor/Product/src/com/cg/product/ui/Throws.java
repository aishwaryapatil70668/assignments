package com.cg.product.ui;

public class Throws  

{

	public void get() throws ArithmeticException 
	{
	int d=2,e=0;

	
	System.out.println(d/e);
	
	}
	
}
