package com.cg.product.ui;

public class Excep {
			public void alll()
			{
				
				int c[]= {1,2,3};

					try {
		
							System.out.println(c[4]);
						}
					catch(Exception e)
						{
							System.out.println("check array");
						}
				
			finally
			{//always execute
				System.out.println("in b");
				
			}
			
			
//	int a[]= {1,2,3};
//
//				try {
//	
//						System.out.println(a[3]);
//					}
//				catch(Exception e)
//					{
//						System.out.println("check array");
//					}
//			
//		finally
//		{//always execute
//			System.out.println("in b");
//			
//		}
		}
}
