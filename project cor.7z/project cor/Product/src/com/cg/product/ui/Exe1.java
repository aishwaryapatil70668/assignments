package com.cg.product.ui;

public class Exe1 {
	
	
	public void getall() {
		// TODO Auto-generated method stub

		int a[]= {1,2,3};
		int c=2,b=0;
		
		
		try
		{ 	
			int e= c/b;
			System.out.println(a[4]);
			
		}catch(ArithmeticException f)
		{
			System.out.println("divide by 0 ");
		}catch(ArrayIndexOutOfBoundsException g)
		{
			System.out.println("df");
		}
		
	
		try {

				System.out.println(a[3]);
			}
		
	
finally
{//always execute
	System.out.println("in b");
	
}
	}

}
