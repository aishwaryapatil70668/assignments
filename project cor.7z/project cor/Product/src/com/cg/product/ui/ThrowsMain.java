package com.cg.product.ui;

public class ThrowsMain {

	public static void main(String[] args)throws ArithmeticException {
		// TODO Auto-generated method stub
 
// 
// try
// {
// new Throws().get();
// }catch(ArithmeticException e)
// {
//	 System.out.println("divide by 0");
//	 
// }
		 new Throws().get();
 System.out.println("swdh");
 
 
 
	}

}
