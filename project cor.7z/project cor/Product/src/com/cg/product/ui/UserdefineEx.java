package com.cg.product.ui;

public class UserdefineEx extends RuntimeException {

	public UserdefineEx()
	{
		super();
		
		
	}
	
	public  UserdefineEx(String msg)
	{
		
		super(msg);//runtime constructor
	}
	
	

}
