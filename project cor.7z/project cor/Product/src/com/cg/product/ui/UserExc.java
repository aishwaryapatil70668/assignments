package com.cg.product.ui;

public class UserExc {

	public void gall(int s)
	{
		if(s<5000)
		{
			throw new  UserdefineEx("salary should greater than 5000");
		}
	
		System.out.println(s);
	}
	
}
