package com.cg.product.ui;

public class ExeMain1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	
	new Exe1().getall();
	
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("check array");
	
}
		
		
	}

}
