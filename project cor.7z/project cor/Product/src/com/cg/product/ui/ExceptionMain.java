package com.cg.product.ui;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public class ExceptionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*try
	{
		FileReader i= new FileReader("a.txt");
		i.read();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
		
		try {
			Class.forName("package com.cg.product.ui.b");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
	System.out.println("class not found");
		}
		
	
		
		
	}

}
