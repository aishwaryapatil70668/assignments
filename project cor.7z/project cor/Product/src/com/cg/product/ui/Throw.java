package com.cg.product.ui;

public class Throw {

	public void getalll() {
		// TODO Auto-generated method stub

		int a[]= {1,2,3};
		int c=2,b=2;
		
		if(b==0)
		{
			
			throw new ArithmeticException("b should greter --user define exception ");
		}
		
		System.out.println(c/b);
		
		
		
		
	}
	
}
