package com.cg.product.ui;

public class UserExMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	try
	{
		new  UserExc().gall(900);
	}
	catch(ArithmeticException a)
	{
		System.out.println(a.getMessage());
	}catch( UserdefineEx e){
		System.out.println(e.getMessage());
	}

	}

}
