package com.cg.product.ui;

public class Throwmain {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		try
		{
		new Throw().getalll();
		
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
		
		System.out.println("hie");
		
		//new Throw().getalll();
		//System.out.println("hie");
	}

}
