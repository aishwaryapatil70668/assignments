package com.cg.product.dto;

import java.util.Scanner;

public class Product {

	public int id;
	public String name;
	public int price;
	public String desc;
	
	
	public void add()
	{
Scanner sc=new Scanner(System.in);
System.out.println();
	
	System.out.println("enter id \n");
	id=sc.nextInt();
	System.out.println("enter name \n");
	name=sc.next();
	System.out.println("enter price \n");
	price=sc.nextInt();
	System.out.println("enter description \n");
	desc=sc.next();
	}
	
	public void show()
	{

System.out.println();
	
	System.out.println("id =" +id);
	
	
	System.out.println("name =" +name);
	
	System.out.println("price =" +price);
	
	System.out.println("enter description = " +desc);
	
	}
	
	
	
	
}
