package com.cg.product.dto;

public class Dozens {
	public static void main(String[] args) { 
		
		try { int x = Integer.parseInt("two"); }
		
	}

		/*
		String o = "-";
		switch("FRED".toLowerCase().substring(1,3)) {
		case "yellow":
		o += "y";
		case "red":
		o += "r";
		case "green":
		o += "g";
		}
		System.out.println(o);
		}
}
		
		
	//	X x1 = new X();
	//	X x2 = new Y();
		//	Y y1 = new Y();
		//	x2.do2();
			((X) new Y()).do1();
	}
}
class X { 
			void do1() { 
				System.out.println("hi");
			}
		}
		class Y extends X {
			
			
			void do1() {
				System.out.println("jiee");
			} 
			
		}

		*/
		/*new Dozens().go(); }
	void go() {
	new Hound().bark();
	((Dog) new Hound()).bark();
	// ((Dog) new Hound()).sniff();
	 }
	}
	
	class Dog {
		 public void bark() { 
			 
			 System.out.print("woof "); }
		}
		 class Hound extends Dog
		 {
		 public void sniff()
		 { System.out.print("sniff "); }
		public void bark() { System.out.print("howl "); }
		 }
		*/
		
		
		/*
			Dozens() { main("hi"); }
			
			public static void main(String[] args) {
				
			main("as");	
			System.out.print("2 ");
			
			}
			public static void main(String args) {
			System.out.print("3 " + args);
			}
			}
	*/

	

/*	
		
		String s = "JAVA";
		s = s + "rocks";
		System.out.println(s);
		s = s.substring(2,5);
	
		//s.toUpperCase();
		System.out.println(s);
		
		StringBuilder sb = new StringBuilder();
		String s = new String();
		for(int i = 0; i < 1000; i++) {
		s = " " + i;
		sb.append(s);
		}
	
		
		
		
		
		
		
		
		
		String s1 = "abc";
		String s2 = s1;
		s1 += "d";
	System.out.println(s1 + " " + s2 + " " + (s1==s2));
		
		StringBuilder sb1 = new StringBuilder("abc");
		 StringBuilder sb2 = sb1;
		 sb1.append("d");
		 System.out.println(sb1 + " " + sb2 + " " + (sb1==sb2));
					
		
		
			 Dozens [] da = new Dozens[3];
			da[0] = new Dozens();
			Dozens d = new Dozens();
			da[1] = d;
			d = null;
		da[1] = null;
			

				char[] ca = {0x4e, \u004e, 78};
			System.out.println((ca[0] == ca[1]) + " " + (ca[0] == ca[2]));
			
		
			String[] horses = new String[5];
			horses[4] = null;
			for(int i = 0; i < horses.length; i++) {
			if(i < args.length)
			horses[i] = args[i];
			System.out.print(horses[i].toUpperCase() + " ");
			}
		
		
		int [] [] array2D = {{0, 1, 2}, {3, 4, 5, 6}};
		//System.out.println(array2D[0].length+ "" );
		System.out.println(array2D[1].getClass(). isArray() + "");
		//System.out.println (array2D[0][1]);*/


