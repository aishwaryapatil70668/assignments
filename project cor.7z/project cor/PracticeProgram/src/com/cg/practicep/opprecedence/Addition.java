
package com.cg.practicep.opprecedence;

import java.util.Scanner;

public class Addition
{	
	
	int a,b,c;
	
	public void addit()
	{ 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		a=sc.nextInt();

		System.out.println("Enter second number");
		b=sc.nextInt();
		c=a+b;
		System.out.println(c);
	}
	
	
	
	public void addi(int x,int y)//Function with arguments and no return value
	{
		int c;
		c=x+y;
		System.out.println("add"+c);
	}

	public static void main(String[] arg)
	{
			int a,b;

			Scanner sc=new Scanner(System.in);
			System.out.println("Enter first number");
			a=sc.nextInt();

			System.out.println("Enter second number");
			b=sc.nextInt();
			
			Addition r=new Addition();
			r.addi(a, b);
			r.addit();


	}
}