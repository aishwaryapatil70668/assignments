package com.cg.practicep.opprecedence;

public class LogicalCondi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int stud=20, room=10;
	int a,b;
		//System.out.println(v3);
		
	
		if(11 > 10 && 11>17 ) //10>0=t  20>30=f 
		{
			System.out.println("crowded");
		}
		System.out.println("end program");
		
	}

}
