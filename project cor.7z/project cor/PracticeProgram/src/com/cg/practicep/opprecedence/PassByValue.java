package com.cg.practicep.opprecedence;

public class PassByValue {
	 

	int a;
	PassByValue b;
	
	
	public PassByValue(int i) {
	
		this.a = i;
	}

	
	void swap( PassByValue a, PassByValue b)
	{
		 PassByValue c;
		 c=a;
		 a=b;
		 b=c;
		 
		System.out.println(a);
		System.out.println(b);
	}
	
	

	@Override
	public String toString() {
		return "PassByValue [a=" + a + ", b=" + b + "]";
	}


	public static void main(String[] args) {
		 PassByValue v1=new   PassByValue(20);
		 PassByValue v2=new  PassByValue(30);
		 v1.swap(v1, v2);
		
	}

}
