package com.cg.practicep.opprecedence;

public class StaticDemo {

	public static void main(String[] args) {
		
		
		G one=new  G();
		one.temp=100;
		 G  two=new G();
		 G three=new G();
		 
		 one.temp=10;
		 one.data=30;
		 
		 G.getAll(three);
	
	
		 System.out.println(three.temp);
		 System.out.println(two.data);
	}

}

class G
{
	int data=10;
	static int temp=30;
	
	public G() {
		System.out.println("in  G ");
	}
	
	public static void getAll(G g)
	{ 
	//	int id;
		
	
		g.data=30;
		g.temp=50;
	
		
	}
	
}
