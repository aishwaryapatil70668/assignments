package com.cg.practicep.opprecedence;

public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		J b=new K();
	//	J b=new J();
		b.a();
		
		
	}

}
class J
{
	
	
	public void a()
	{
		System.out.println("s");
	}
	static int b =60;
	 J()
	{
		
	System.out.println("IN B");
	
}
}


class K extends J
{
	

	public void a()
	{
		System.out.println("b");
	}
	K(){
		System.out.println("IN A"+b);
	}
	
	
}