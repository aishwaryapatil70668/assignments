package com.cg.practicep.opprecedence;

public class ObjectClass {

	public static void main(String[] args) {
	
		B temp=new B();
		temp.get();
		System.out.println(temp.a);
		
	}

}

class A
{
	int a=10;
	public A()
	{
		System.out.println("class a");
	}
	
	public void get()
	{
		System.out.println("class A  method");
	}
	
}

class B extends A
{
	public B()
	{
		//super
		System.out.println("CLASS B");
	}
}




