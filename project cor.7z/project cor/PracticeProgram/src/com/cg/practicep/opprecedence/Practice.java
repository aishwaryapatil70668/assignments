package com.cg.practicep.opprecedence;

public class Practice {
	
	
	
	private int f=20;
	
	
	public int get() {
	
	return f;
	}
	
	{
		f=3;
	}
	
	
	public Practice() {
		
		f=2;
	}
	
	
	public static void main(String[] args) {
	
		Practice p=new Practice();		
		
		System.out.println(p.get());
		
		
		}
	}


