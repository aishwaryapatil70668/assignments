package com.cg.practicep.opprecedence;

public class Arrays {

	public static void main(String[] args) {
		
		int[] b= {1,3,4};
	 System.out.println(b[0]);
		
		
		
		int[] n = new int[3];
		
		n[0]=2;
		n[1]=22;
		n[2]=222;
		
		for(int i=0;i<n.length;i++)
		System.out.println(n[i]);
		
		

	}

}
