package com.cg.practicep.opprecedence;

public class Precedence {

	
	public static void main(String[] args) {
		
	
	
		int a=20, b=10,c=5,res1 ,res2;
		
		res1=a-b/c;
		System.out.println(res1);
		
		
		res2=(a-b)/c;
		System.out.println(res2);

	}

}
