package com.cg.practicep.opprecedence;

public class ConditionalAss {

	public static void main(String[] args) {
		
		int a=10,b=5;
		int v3= a < b ? a : b;
	//	System.out.println(v3);
		
		int i =7 & 2;
		System.out.println(i);
		float s=30;
		float r=2;
		float s1=r==0.0f?0.0f:s/r;
		//System.out.println(s1);
		
		
	}

}
