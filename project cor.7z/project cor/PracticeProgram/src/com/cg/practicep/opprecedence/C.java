package com.cg.practicep.opprecedence;

public class C {
	
	 static String name; // Line1
		public C() 
		{
		  name = "Sara";
		   }
		
		
//		static {
//			System.out.println("in A class static block");
//		}
//		
//		public static void getd()
//		{
//			System.out.println("in A classs static method");
//		}
//		
		public static void main(String[] args) 
		
		{
				name="dfg";
		  System.out.println(C.name);
		}
		


}
