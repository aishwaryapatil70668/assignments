package com.cg.practicep.opprecedence;

public class TypeConv {

	public static void main(String[] args) {
	int a=20;
		
		
		long d=a;//implicit conversion
		System.out.println(d);
	//	int b=d;
		int e=(int) d;
		
		System.out.println(e);
		
		int k = 30;
		long l = k;
		float m = l;
		double n = m;
			    
		System.out.println("int value : "+k);
		System.out.println("long value : "+l);
		System.out.println("float value : "+m);
		System.out.println("double value : "+n);
			
		float lval=45.200f; //explicit with cast operator
		int kval =(int) lval;
		System.out.println(kval);
		
		double b=100.04;
		int c=(int) b;
		System.out.println(c);
		
		
	}

}
