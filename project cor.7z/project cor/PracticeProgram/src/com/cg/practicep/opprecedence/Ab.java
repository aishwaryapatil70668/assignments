package com.cg.practicep.opprecedence;




public class Ab {
	
	int bag, cbag;
	
	public Ab() {
		System.out.println("ff");
		
	}
	
	public Ab(String s) {
		System.out.println("as");		
	}


}

public class bbb extends Ab  {
	
	int bag, cbag;
	
	public bbb() {
		System.out.println("ff");
		
	}
	
	public bbb(String s) {
		System.out.println("as");		
	}

	

	public static void main(String[] args) {
		
		 new bbb("bv");
		//System.out.println(n);

	}

}
