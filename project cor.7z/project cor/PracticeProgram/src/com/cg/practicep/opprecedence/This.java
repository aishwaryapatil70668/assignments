package com.cg.practicep.opprecedence;

public class This {
/*
	int a;
	int b;

	 public void setData(int c ,int d){
		 a = c;
		 b = d;
	
	 }
	 void showData() {
		 System.out.println("Value of A ="+a);
	   System.out.println("Value of B ="+b);
	 }
	 public static void main(String args[]){
	 This obj = new This();
	   obj.setData(2,3);
	   obj.showData();
	   
	   This obj2 = new This();
	   obj2.setData(3,3);
   obj2.showData();
	   
	 }
	
	*/
	int a;
		int b;

		 public void setData(int a ,int b){
			a = a;
			b = b;
		 
		 }
		 public void showData(){
			 System.out.println("Value of A ="+a);
			   System.out.println("Value of B ="+b);
		 }
		 public static void main(String args[]){
		 This obj = new This();
		   obj.setData(2,3);
		 obj.showData();
		 }
		}