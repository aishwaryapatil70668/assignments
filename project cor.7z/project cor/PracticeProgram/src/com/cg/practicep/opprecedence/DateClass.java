package com.cg.practicep.opprecedence;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Scanner;

public class DateClass {

	public static void main(String[] args) throws ParseException {
		
		
		
		//Date date=new Date();
		//System.out.println(date);
		
		
		Scanner in = new Scanner(System.in);
		System.out.println("enter date");
	
		String date=in.next();
		SimpleDateFormat f=new SimpleDateFormat("dd/mm/yyyy");
		
		Date gdate=f.parse(date);
		
	System.out.println(f.format(gdate));
	
	
		
		LocalDate ldate= LocalDate.now();
		System.out.println("hg"+ldate);
		System.out.println(ldate.getDayOfMonth());
		System.out.println(ldate.isLeapYear());
		System.out.println(ldate.plusDays(2));


		LocalDateTime tdate= LocalDateTime.now();
		System.out.println(tdate);

		ZonedDateTime zone=ZonedDateTime.now();
		System.out.println(zone);
	
	
		ZonedDateTime zone1=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		System.out.println(zone1);
	
	
	}

}
