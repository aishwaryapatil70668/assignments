package com.cg.practicep.opprecedence;

public class Static1 {

	
	
	static {
		System.out.println("hi in main static block");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" in main");

		//L.getAll();
		C.getd();
		
	}

}
/*
class C
{ 
	static {
		System.out.println("in A class static block");
	}
	
	public static void getd()
	{
		System.out.println("in A classs static method");
	}
	
	public static void main(String[] args) 
	
	{
		 
	}
	
	*/
	/*ublic class Staticthree {

		
		
		
		public static void main(String[] args) {
			
			b.B t=new b().new B();
		
			// B temp = new A.b();
			t.getAll();
			 b demo =new b();
			 demo.ge();
			
			
		}

	}

	 class b
		{ 	int a=10;

			class B
			{
				int b=20;
				public void getAll()
				{
					System.out.println(b);
				}
			}
			
			public void ge() {
			
				System.out.println("in a");
			}
			
	}
*/

