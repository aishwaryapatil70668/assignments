package com.cg.practicep.opprecedence;
import java.math.BigDecimal;
import java.math.BigInteger;

public class BigInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	
		BigInteger A=new BigInteger("12341242342343");
		BigInteger B=new BigInteger("547567586787");
		BigInteger Sum=A.add(B);
		System.out.println("Sum Of the two Numbers is :"+Sum);
		
		 BigDecimal bd = new BigDecimal("-12345.6789");
         int s=2;
         
	}



}
