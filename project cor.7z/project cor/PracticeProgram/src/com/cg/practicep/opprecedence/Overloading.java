package com.cg.practicep.opprecedence;

public class Overloading {

	public static void main(String[] args) {
		//new M().getAll();
	L a= new M();
	a.getAll();


	System.out.println(a.b);
	}

}


class L
{ static  int b=10;
	public void getAll()
	{
		System.out.println("IN L.....");
	}
}



class M extends L
{
	public void getAll()
	{
		int b=2;
		System.out.println("IN M.....");
	}
	
}
	
	