package com.cg.practicep.opprecedence;

public class CalcEngine {

	public static void main(String[] args) {
		
		int a= 100;
		int b= 30;
		
		int res = 0;
		char op='a'; 
		
		if(op=='a')
		{
		res= a+b;
		System.out.println(res);
		}
		else if(op=='b')
		{
			res= a-b;
			System.out.println(res);
		}
		else if(op=='c')
		{
			res= a*b;
			System.out.println(res);
		}
		else if(op=='d') 
		{
			res= a/b;
			System.out.println(res);
		}
		else
			System.out.println("false");
		
		
		
	}

}
