package com.cg.practicep.opprecedence;

import java.util.Scanner;

public class Add {

	public int a,b,c;
	
	
	public int add()//Function with no arguments and a return value
	{
		int a=10,b=30;
		c=a+b;
		return c;
	}
	
	public static void main(String[] args) {
	
		Add n=new Add();
		int z;
		z=n.add();
		System.out.println(z);
	}
	
	
	/*public int add(int a, int b)  //Function with arguments and a return value
	{
		c=a+b;
		return c;
		
	}
	public static void main(String[] args) {
	
			int x,y,z;
			Add n=new Add();
			
			System.out.println("Enter two number");
			Scanner in = new Scanner(System.in);
	     
	     x = in.nextInt();
	      y = in.nextInt();
	 z=n.add(x,y);
System.out.println(z);
*/
	
	
	
	
	
}
