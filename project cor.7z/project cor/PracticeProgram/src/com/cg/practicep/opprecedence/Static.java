package com.cg.practicep.opprecedence;

public class Static {
 
	
	double s=20;
	static double sal=300;
	
	static void getdata(int id) {
		sal=id;
		System.out.println("static");
	}
	void getd() 
	{
		System.out.println("non static method");
	}
	
	public static void main(String[] args) {
	
		
		Static n=new Static();
		Static n1=new Static();
		System.out.println(n.s);
		System.out.println(n1.s);
		//System.out.println(n.getd());
			n.getd();
		//System.out.println(n);
		//getdata.getd();
	//	getd();
		getdata(300);
		
		
		
	}

}
