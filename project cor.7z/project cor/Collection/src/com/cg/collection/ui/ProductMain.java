package com.cg.collection.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.coll.exe.EmployeeExe;
import com.cg.coll.exe.ProductExce;
import com.cg.coll.service.ProductServiceI;
import com.cg.coll.service.ProductServiceImpl;
import com.cg.collection.dto.Employee;
import com.cg.collection.dto.Product;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProductServiceI service=new ProductServiceImpl();
		int ch;
		Scanner s=new Scanner(System.in);
		do
		{
			
			System.out.println("1.add product");
			System.out.println("2.show product");
			System.out.println("3.Search by id");
			
			System.out.println("4.update price");
			System.out.println("5.Search by price");
			System.out.println("5. sort");
			
			
			System.out.println("Enter the choice");
			ch=s.nextInt();
		switch(ch)
		{
		case 1: 
			System.out.println("enter product detail");
			System.out.println("Enter ID");
			int id=s.nextInt();
			System.out.println("enter name");
			String name=s.next();
			System.out.println("enter price");
			double price=s.nextDouble();
			System.out.println("enter description");
			String descr=s.next();
			
			Product prod=new Product();
			prod.setId(id);
			prod.setName(name);
			prod.setPrice(price);
			prod.setDescr(descr);
			
			
			service.addProduct(prod);
			
			break;
		
		
		
		
		case 2: 
			System.out.println("product details are");
			
			List<Product> prodlist=service.showall();
			
			for(Product proddata: prodlist)
			{
			
			System.out.println("id is=  "+proddata.getId());
			System.out.println("name is= " +proddata.getName());
			System.out.println("price is= "+proddata.getPrice());
			System.out.println("desc is= "+proddata.getDescr());
			}
			
			
			
			
			break;
		case 3:
			System.out.println("enter id");
			int idd=s.nextInt();
			Product prodsearch =service.searchid(idd);
			
				
				System.out.println("id is "+prodsearch.getId());
			
			
			
			break;
	
		
		case 4:
			System.out.println("enter the employee id");
			int sid=s.nextInt();
			try
			{
			Product psearchid =service.searchid(sid);
			if(psearchid!=null)
			{
			System.out.println(psearchid);
			System.out.println("enter Price");
		
			double pricee=s.nextDouble();
			
			psearchid.setPrice(pricee);
			
			service.update(psearchid);
			}
			
			}catch(ProductExce e)
			{
				
				System.out.println(e.getMessage());
			}
			
			break;
			
			
			
		case 5: 
			System.out.println("search product by price ");
			
			double min=1000;
			double max=2000;
			
			
			List<Product> prodctlist=service.searchByPrice(min, max);
			
			for(Product proddata: prodctlist)
			{
			System.out.println("prices is"+proddata.getPrice());
			
			
		}
			break;
			
			
		}
		}while(ch!=6);
		
		
		
	}

}
