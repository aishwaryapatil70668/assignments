package com.cg.collection.ui;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Collection {

	public static void main(String[] args) {
		
	
		
		// TODO Auto-generated method stub
		
	 List<Integer> mylist=new LinkedList<Integer>();
	
		mylist.add(1);
		mylist.add(2);
		
		System.out.println(mylist);
		 List<String> list=new LinkedList<String>();
			list.add("a");
			list.add("b");
			list.add("a");
			
			System.out.println("using for each");
			System.out.println();
			for(String list1:list)
			{
				System.out.println(list1);	
			}
			
			
			System.out.println("using iterator");
		Iterator<String> it=list.iterator();//list strores strings so we passing data
		//providing methods
		
		while(it.hasNext())
		{
			
			System.out.println(it.next());
		}
		
		
		
	}
	
	

}
