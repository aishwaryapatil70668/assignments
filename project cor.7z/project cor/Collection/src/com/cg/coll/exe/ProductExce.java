package com.cg.coll.exe;

public class ProductExce  extends  RuntimeException{

	public   ProductExce()
	{
		super();
	}
	

	public   ProductExce (String msg)
	{
		super(msg);
	}


	
	
}
