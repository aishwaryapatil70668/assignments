package com.cg.coll.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.cg.coll.dao.ProductDao;
import com.cg.coll.dao.ProductDaoI;

import com.cg.coll.exe.ProductExce;
import com.cg.collection.dto.Product;


public class ProductServiceImpl implements ProductServiceI {

	
 ProductDaoI proddao;
	public ProductServiceImpl()
	{
		proddao =new ProductDao();
		
	}
	
	
	
	
	@Override
	public void addProduct(Product prod) {
		// TODO Auto-generated method stub
	 proddao.save(prod);
	}

	@Override
	public List<Product> searchByPrice(double min,double max) {
		// TODO Auto-generated method stub
		return proddao.findByPrice(min,max);
	}

	@Override
	public List<Product> showall() {
		// TODO Auto-generated method stub
		return proddao.showall();//IF NOT RETURN THEN GIVES NULL POINTER
	}

	@Override
	public Product update(Product prod)  throws ProductExce {
		
	
		return null;
	}

	@Override
	public boolean remove(Product Prod) {
		// TODO Auto-generated method stub
		return true;
	}




	@Override
	public Product searchid(int id) {
		// TODO Auto-generated method stub
		return 	proddao.findById(id);
	}




	@Override
	public void sort() {
		// TODO Auto-generated method stub
		
	}




	



	




		
		
	

}
