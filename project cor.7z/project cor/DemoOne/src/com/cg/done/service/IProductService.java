package com.cg.done.service;

import com.cg.done.dto.Product;

public interface IProductService {
	public  Product addp(Product prod);
	public Product[] show();
}
