package com.cg.done.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.done.dto.Product;
import com.cg.done.service.IProductService;
import com.cg.done.service.ProductService;



class ProdctTest {
IProductService service; 
	
	Product prod;
	@BeforeEach
	public void beforeTest() {
		service=new ProductService();
		prod=new Product();
		
		prod.setId(100);
		prod.setName("mobile");
		prod.setPrice(3000.0);
		prod.setDescr("its an iphone");
		
	}
	@Test
	public void Test() {
		assertNotNull(service.addp(prod));
	}
	
	@Test
	public void Testtwo() {
		assertNotNull(service.show());
		
	}
	@AfterEach
	public void afterTest() {
		service=null;
	}
	

}
