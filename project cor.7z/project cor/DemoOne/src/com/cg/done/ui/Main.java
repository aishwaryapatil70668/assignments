package com.cg.done.ui;

import java.util.Scanner;

import com.cg.done.dto.Product;

public class Main {

	public static void print()
	{
		
		
		System.out.println("1.add \n 2.show");
		System.out.println("exit");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		print();
		
		Scanner sc=new Scanner(System.in);
		int ch=0;
		do
		{	Product pro=new Product();
			System.out.println("enter choice");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("add");
				System.out.println("enter id \n");
				int id=sc.nextInt();
				System.out.println("enter name \n");
				String name=sc.next();
				System.out.println("enter price \n");
				double price=sc.nextInt();
				System.out.println("enter description \n");
				String desc=sc.next();
				
				
				
				
				break;
			case 2: 
				System.out.println("show");
				break;
			case 3:
				System.exit(0);
				break;
				
				
				
			}
			
			
		}while(ch!=3);
		
		
	}

}



