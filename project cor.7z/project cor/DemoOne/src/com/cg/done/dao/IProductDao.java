package com.cg.done.dao;

import com.cg.done.dto.Product;

public interface IProductDao {
	
	public Product addp(Product pro);
	public Product[] show();
	

}
