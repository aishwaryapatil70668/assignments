package com.cg.booking.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import com.cg.booking.dto.Room;
import com.cg.booking.util.ConnectionDBUtil;

public class RoomDaoImpl implements IRoomDao {

EntityManager em;
	
	public RoomDaoImpl() {
		em=ConnectionDBUtil.em;
	}
	
public Room save(Room room) {
	em.getTransaction().begin();
	
	em.persist(room);
	em.getTransaction().commit();
	return null;
	
}

public List<Room> findByRoomType(String Type) {

		Query query = em.createQuery("FROM Room r where r.type = :type ");
		query.setParameter("type", Type);
		List<Room> roomtype = query.getResultList();
		
		return roomtype;
	}

	
	

}
