package com.cg.demoCollection.dto;

import java.util.Comparator;

public class EmpSorting implements Comparator<Employee> {

	public int compare(Employee o1, Employee o2) {
		
		
		//return o1.getName().compareToIgnoreCase(o2.getName());
		
		
		// TODO Auto-generated method stub
		if(o1.getId()<o2.getId())
		{
			return -1;
		}else if(o1.getId()>o2.getId())
		{
			
			return 1;
			
			
		}else 
			
		
		
		
		return 0;
	}

}
