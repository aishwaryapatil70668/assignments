package com.cg.demoCollection.dto;

import java.util.HashSet;
import java.util.Set;

public class PersonMain {
	

	public static void main(String[] args) {
		
		Person pone=new Person("aish");
		Person ptw = new Person("sonal");
		Person ptth=new Person("priya");
		Person pt4=new Person("priyp");
		System.out.println(ptth.hashCode());
		System.out.println(pt4.hashCode());
		Person pt5=new Person("aniket");
		Person pt6=new Person("sidhu");
		Person pt7=new Person("kajal");
		Person pt8=new Person("shivani");
		
		
Set<Person> setempp=new HashSet<Person>();
		
		setempp.add(pone);
		setempp.add(ptw);
		setempp.add(ptth);
		setempp.add(pt4);
		setempp.add(pt5);
		setempp.add(pt6);
		setempp.add(pt7);
		setempp.add(pt8);
		
	}

}
