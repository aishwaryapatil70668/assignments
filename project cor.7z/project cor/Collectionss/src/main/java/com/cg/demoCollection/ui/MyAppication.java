package com.cg.demoCollection.ui;

import java.util.Set;
import java.util.TreeSet;

import com.cg.demoCollection.dto.Employee;

public class MyAppication {

	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Set<String> setemp=new TreeSet<String>();
		
		setemp.add("4");
		setemp.add("p");
		setemp.add("a");
		setemp.add("A");
		setemp.add("Q");
		setemp.add("z");
		setemp.add("1");
		System.out.println(setemp);
	}

	
		
	
			
			
	
}
