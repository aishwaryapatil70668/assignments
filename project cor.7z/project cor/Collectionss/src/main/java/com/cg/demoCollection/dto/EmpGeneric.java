package com.cg.demoCollection.dto;

import java.util.Comparator;

public class EmpGeneric<T,K> implements Comparator<EmpGeneric<T, K>>{
public T  id;
public String name;
public K salary;
public EmpGeneric() {
	
}



public EmpGeneric(T id, String name, K salary) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
}



public T getId() {
	return id;
}
public void setId(T id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public K getSalary() {
	return salary;
}
public void setSalary(K salary) {
	this.salary = salary;
}



@Override
public String toString() {
	return "EmpGeneric [id=" + id + ", name=" + name + ", salary=" + salary + "]";
}



public int compare(EmpGeneric<T, K> o1, EmpGeneric<T, K> o2) {
	// TODO Auto-generated method stub
	return o1.getName().compareToIgnoreCase(o2.getName());
}








	
	
	
	
}
