package com.cg.demoCollection.ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.cg.demoCollection.dto.EmpGeneric;

public class MapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmpGeneric<Integer,Double> empp=new EmpGeneric<Integer,Double>(1001,"R",4000.0);
		EmpGeneric<Integer,Double> empp1=new EmpGeneric<Integer,Double>(1002,"V",4000.0);
		EmpGeneric<Integer,Double> empp2=new EmpGeneric<Integer,Double>(1003,"D",4000.0);
		
		
		Map<Integer,EmpGeneric> mymap=new HashMap<Integer,EmpGeneric>(); 
		
		mymap.put(1, empp);
		mymap.put(2, empp1);
		mymap.put(3, empp2);
		
		
		Collection<EmpGeneric> mycoll=mymap.values();
		
		List<EmpGeneric> emplist=new ArrayList<EmpGeneric>() ;
		
		
			
		
		
		
//	System.out.println(mymap.get(1));
		
	//for(Integer it: mymap.keySet())//print employee data using key
//	{
		
	//	System.out.println(mymap.get(it)); 
	//}
	
	
		
	   
	    
	}
	
	
	
		
		
		//mymap.put(1011, "A");
		
	//	mymap.put(102, "Z");
		//mymap.put(null, "Z");
		//mymap.put(null, "B");
		//mymap.put(1011, "B");
	//	mymap.put(1011, "C");
		//mymap.put(1003, "B");
		
		
		
	

}
