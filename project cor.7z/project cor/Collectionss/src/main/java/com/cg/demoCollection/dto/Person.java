package com.cg.demoCollection.dto;

public class Person {

	
	
	private String name;
    static int count;
	
	
	
	public Person() {
		
	}
	
	

	public Person(String name) {
		super();
		this.name = name;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}



	@Override
	public int hashCode() {
		
		System.out.println("hashcode called ");
		
	//	return 10;
		
		
		return name.hashCode();
		//return name.charAt(0);
	}



	@Override
	public boolean equals(Object obj) {
		
		count++;
		Person other = (Person) obj;
		System.out.println("equals called \t"+count);
	
		return this.getName().equals(other.getName());
	}
	
	
}
