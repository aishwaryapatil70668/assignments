package com.cg.labone.dto;

public class Author {

	private	int id;
	private	String fName;
	private	String mName;
	private	String lName;
	private int no;
	
	
	
	public Author() {
		super();
	}



	public Author(int id, String fName, String mName, String lName, int no) {
		super();
		this.id = id;
		this.fName = fName;
		this.mName = mName;
		this.lName = lName;
		this.no = no;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getfName() {
		return fName;
	}



	public void setfName(String fName) {
		this.fName = fName;
	}



	public String getmName() {
		return mName;
	}



	public void setmName(String mName) {
		this.mName = mName;
	}



	public String getlName() {
		return lName;
	}



	public void setlName(String lName) {
		this.lName = lName;
	}



	public int getNo() {
		return no;
	}



	public void setNo(int no) {
		this.no = no;
	}



	@Override
	public String toString() {
		return "Author [id=" + id + ", fName=" + fName + ", mName=" + mName + ", lName=" + lName + ", no=" + no + "]";
	}	
	
	
}
