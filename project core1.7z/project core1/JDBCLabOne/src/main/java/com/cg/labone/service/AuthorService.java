package com.cg.labone.service;

public class AuthorService {

	
	
}
