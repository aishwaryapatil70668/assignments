package com.cg.labone.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

public class DBUtil {

	
	static Connection con;
	
		public static Connection getConnection()
		{
			Properties prop=new Properties();
			InputStream it;
			try {
				it = new FileInputStream("src/main/resources/jdbc.properties");
				prop.load(it);
				
				if(con==null)
				{
					
					if(prop!=null)
					{
						
						
					}
				}
				
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			return con;
			
		}
	

}
