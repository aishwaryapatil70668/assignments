package com.cg.jdbc.demo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;


public class Delete {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		try	{
//			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
//			Connection conn = 
//			DriverManager.getConnection (
//			"jdbc:oracle:thin:@192.168.67.177:1521:trgdb", "user2", "user2");
//
//			
//			Statement stmt = conn.createStatement (); 
//			int count = stmt.executeUpdate ("delete from employee_1 where empno=40705");
//			
//			
//			System.out.println("No of Records deleted :="+count);
//			
//		} catch (SQLException e) {
//			System.out.println(e.getMessage());
//		}
//		
		
		           Set hashSet = new HashSet();
		            hashSet.add("5");
		            hashSet.add(null);                                                                                                                                                                                                                                                                                                                                            
		            hashSet.add(null);
		           hashSet.add("3");
		           System.out.println(hashSet);                                              
		    
	

		
	}

}
