package com.cg.lab5.ui;

import java.util.Scanner;

public class AssignmentTwo {
	
	     public static void main(String[] args) {
	         
	         int i,n1=1,n2=1,n3,n;
	         
	         
	          Scanner s=new Scanner(System.in);
	          System.out.println("enter number");
	          n=s.nextInt();
	          
	         
	          for (i = 1; i <= n; i++)
	          {
	        	  System.out.println(n1);
	        	  n3=n1+n2;
	              n1=n2;
	              n2=n3;
	             
	              
	            
	          }
	        
	          
	          
	     }
	}
