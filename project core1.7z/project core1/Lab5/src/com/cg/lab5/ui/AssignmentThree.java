package com.cg.lab5.ui;

import java.util.Scanner;

public class AssignmentThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n, i = 3, count, c;
		 
		  Scanner s=new Scanner(System.in);
		 System.out.println("Enter the number of prime numbers required\n");
		   n=s.nextInt();
		 
		   if ( n >= 1 )
		   {
			   System.out.println("First prime numbers are :\n");
			   System.out.println(n);
		   }
		 
		   for ( count = 2 ; count <= n ;  )
		   {
		      for ( c = 2 ; c <= i - 1 ; c++ )
		      {
		         if ( i%c == 0 )
		            break;
		      }
		      if ( c == i )
		      {
		    	  System.out.println(i);
		         count++;
		      }
		      i++;
		   }
	}
}
		 
		 
		

