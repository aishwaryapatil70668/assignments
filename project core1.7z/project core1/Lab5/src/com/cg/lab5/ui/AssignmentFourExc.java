package com.cg.lab5.ui;



public class AssignmentFourExc {

	
	public void getAll(String fName,String lName)
	{
		
		if(fName==""  || lName=="" )
		{
			throw new AssignmentFour("name and last name should be blank");
			
		}
		System.out.println(fName+"  "+lName);
	}
		
		
	public void getAge(int age)
	{
		
		if(age<15)
			
		{
			throw new AssignmentFour("age should be greater than 15");//goes to parameterized constructor
			
		}
		System.out.println(age);
		
		
	}
	
	public void getSalary(int salary)
	{
		if(salary<5000)
		{
			throw new  AssignmentFour("salary should greater than 5000");
		}
	
		System.out.println(salary);
		
	}	
		
	
}
