package com.cg.lab5.ui;



public class AssignmentFourMain {

	public static void main(String[] args) {
		
		try
		{
		new  AssignmentFourExc().getAll("","");
		}
		catch(AssignmentFour a)
		{
			System.out.println(a.getMessage());
		
		}
		
		try
		{
		new  AssignmentFourExc().getAge(5);
		}
		catch(AssignmentFour a)
		{
			System.out.println(a.getMessage());
			
		}
		
		try
		{
		new  AssignmentFourExc().getSalary(50);
		}
		catch(AssignmentFour a)
		{
			System.out.println(a.getMessage());
		
		}
		
		
		}
}
