package com.cg.lab5.ui;

public class AssignmentFour extends RuntimeException {

			
		public  AssignmentFour()
		{
			super();
		}
		

		public  AssignmentFour(String msg)
		{
			super(msg);
		}

}
