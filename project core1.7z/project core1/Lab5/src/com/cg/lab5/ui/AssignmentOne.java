package com.cg.lab5.ui;

import java.util.Scanner;

public class AssignmentOne {

	      public static void main(String[] args) {
	          Scanner s=new Scanner(System.in);
	          int ch;
	          char ans,a;
	        
	         do
	         {
	             System.out.println("******MENU*******");
	             
	             System.out.println("1.red\n 2.green \n 3.yellow\n 4.Exit");
	              System.out.println("Enter youe chloice");
	              ch=s.nextInt();
	              
	             switch(ch)
	             
	             {
	             case 1: System.out.println("stop");
	             break;
	             case 2: System.out.println("go");
	             break;
	             case 3: System.out.println("ready");
	             break;
	             
	             }
	              System.out.println("\n Do you want to continue ? (y/n)");
	              ans=s.next().charAt(0);
	                 
	             
	         }while(ans=='y'||ans=='Y');
	          
	          
	          
	      }
	}
