package com.cg.lab.ui;

import java.util.Scanner;

public class CalSum {
public int calculateSum(int n)
	{
	    
		int i,addition=0;
		
		for(i=0;i<=n;i++)
		{
			if(i%3==0 && i%5==0)
			{
				System.out.println("no. which are divisible by 3 or 5 \t "+i);
				addition=addition+i;
				//System.out.println(addition);
			}
		}
	
		return addition;
	}
	public static void main(String[] args) {
		int z;
		
		CalSum s=new CalSum();
		int number;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter number till divisble by 3 or 5");
		number=sc.nextInt();
		
		z=s.calculateSum(number);
		System.out.println(z);
	}

}
