package com.cg.lab.ui;

import java.util.Scanner;

class Order {
	 
	public boolean checkNumber(int num)
	{ 
	
		boolean flag=true;
		int currentDigit = num % 10;
		num = num/10;
      
   
     while(num>0)
     {
        
         if(currentDigit <= num % 10)
         {
             flag = false;
             break;
         }
         currentDigit = num % 10;
         num = num/10;
    
     }  
	
     if(flag==false)
     {
         System.out.println("Digits are not in increasing order.");
     }
     else
     {
         System.out.println("Digits are in increasing order.");
     }
     return flag;
}
    
	public static void main(String args[]) {
        
     Order n=new Order();
       int num;
       boolean result;
       Scanner scanner = new Scanner(System.in);
        
      
       System.out.println("Enter a number : ");
       num = scanner.nextInt();
       
       
        result=n.checkNumber(num);
       
        System.out.println(result);
       
      
    }
}