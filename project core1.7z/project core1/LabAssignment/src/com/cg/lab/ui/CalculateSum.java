package com.cg.lab.ui;

import java.util.Scanner;

public class CalculateSum {

	public int calculateDiffernce(int n) {
		
		int i,sum=0,diff=0,diff1=0;
		
		for(i=0;i<=n;i++)
		{	
			diff=diff+(i*i);
			sum=sum+i;
			diff1=sum*sum;
			
		}
		System.out.print("difference between sum of the squares of the numbers & square of their sum  ");
		return diff-diff1;
	}
	
	public static void main(String[] args) {
		int z;
		
		CalculateSum s=new CalculateSum();
		int number;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter number");
		number=sc.nextInt();
		
		z=s.calculateDiffernce(number);
		System.out.println(z);
		
	}

}
