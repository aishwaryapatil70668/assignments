package com.cg.jpa.main;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.jpa.dto.Address;
import com.cg.jpa.dto.Department;
import com.cg.jpa.dto.EmployeeOne;
import com.cg.jpa.service.EmployeeServiceImpl;
import com.cg.jpa.service.EmployeeServiceJpa;

import javassist.compiler.ast.Symbol;

public class MyJPAEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeServiceJpa service = new EmployeeServiceImpl();
		Scanner sc=new Scanner(System.in);
		int ch;
		System.out.println("enter id");
		int id=sc.nextInt();
		
		System.out.println("enter name");
		String name=sc.next();
		
		System.out.println("enter salary ");
		double sal=sc.nextDouble();
		
		boolean type=true;
		System.out.println("Enter date of joning");
		String date=sc.next();
		
		System.out.println("enter dept id");
		int did=sc.nextInt();
		
		System.out.println("enter dept  name");
		String dname=sc.next();
		
		Department dept= new Department();
		dept.setId(did);
		dept.setName(dname);
		
		EmployeeOne emp= new EmployeeOne();
		emp.setId(id);
		emp.setName(name);
		emp.setSalary(sal);
		emp.setDateofjoing(new Date());
		emp.setAdd(null);
		emp.setDep(dept);
		emp.setType(type);
		Address add= new Address("nagar","maha",1002);
		emp.setAdd(add);
		service.addemp(emp);
		List<EmployeeOne> mylist=service.serachbysal(2000, 3000);
		for(EmployeeOne empl: mylist)
		{
			
			System.out.println("id"+empl.getId());
			System.out.println("name"+empl.getName());
			System.out.println("name"+empl.getSalary());
			System.out.println("name"+empl.getDep().getId());
			
			
			
		}
					
		System.out.println("enter dept  name");
		String dname1=sc.next();
	
		List<EmployeeOne> mylis=service.searchbydeptname(dname1);
		for(EmployeeOne empl: mylis)
		{
			
			System.out.println("id"+empl.getId());
			System.out.println("name"+empl.getName());
			System.out.println("name"+empl.getSalary());
			System.out.println("name"+empl.getDep().getId());
			
			
			
		}
					
		
		
			
	}

}
