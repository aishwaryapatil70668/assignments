package com.cg.jpa.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="employeeonee")
public class EmployeeOne {

	@Id 
	@Column(name="emp_id")
	private int id;
	@Column(name="emp_name")
	private String name;
	@Column(name="emp_salary")
	private double salary;
	@Column(name="emp_type")
	private boolean type;
	@Column(name="emp_dateofjoining")
	
	
	private Date dateofjoing;
	@Embedded
	private Address add;
	
	
//@OneToMany
//private Department dep;
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="dep_id")
	private Department dep;
		
	public Department getDep() {
		return dep;
	}

	public void setDep(Department dep) {
		this.dep = dep;
	}

	public EmployeeOne() {
		
	}

	
	

	
	public EmployeeOne(int id, String name, double salary, boolean type, Date dateofjoing, Address add,
			Department dep) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.type = type;
		this.dateofjoing = dateofjoing;
		this.add = add;
		this.dep = dep;
	}

	public Address getAdd() {
		return add;
	}

	public void setAdd(Address add) {
		this.add = add;
	}

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public boolean isType() {
		return type;
	}



	public void setType(boolean type) {
		this.type = type;
	}



	public Date getDateofjoing() {
		return dateofjoing;
	}

	public void setDateofjoing(Date dateofjoing) {
		this.dateofjoing = dateofjoing;
	}
/*
	public Department getDep() {
		return dep;
	}

	public void setDep(Department dep) {
		this.dep = dep;
	}*/

	@Override
	public String toString() {
		return "EmployeeOne [id=" + id + ", name=" + name + ", salary=" + salary + ", type=" + type + ", dateofjoing="
				+ dateofjoing + ", add=" + add + ", dep=" + dep + "]";
	}

	
	

	
	
	
	
	
	
}
