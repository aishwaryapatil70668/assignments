package com.cg.jpa.service;

import java.util.List;

import javax.persistence.Query;

import com.cg.jpa.dao.EmployeeDao;
import com.cg.jpa.dao.EmployeeDaoImpl;
import com.cg.jpa.dto.EmployeeOne;

public class EmployeeServiceImpl implements EmployeeServiceJpa {

EmployeeDao dao;
public EmployeeServiceImpl()
{
	
	dao =new EmployeeDaoImpl();
}

	
	public void addemp(EmployeeOne emp) {
		// TODO Auto-generated method stub
		dao.save(emp);
	}

	public List<EmployeeOne> serachbysal(double low, double high) {
		
	
		
		
		return dao.findbysal(low, high);
	}

	public List<EmployeeOne> searchbydeptname(String name) {
		
		
		
		
		
		return null;
	}

}
