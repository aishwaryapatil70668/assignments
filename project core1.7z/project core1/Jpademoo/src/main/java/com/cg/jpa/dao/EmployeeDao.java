package com.cg.jpa.dao;

import java.util.List;

import com.cg.jpa.dto.EmployeeOne;

public interface EmployeeDao {

	public void save(EmployeeOne emp);
	public List<EmployeeOne> findbysal(double low,double high);
	public List<EmployeeOne> findbydeptname(String name);
	
}
