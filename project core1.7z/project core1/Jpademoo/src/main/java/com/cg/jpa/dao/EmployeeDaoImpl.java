package com.cg.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpa.dto.EmployeeOne;
import com.cg.jpa.dutil.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	EntityManager em;
	
public EmployeeDaoImpl()
{
	
	em=DBUtil.getcon();
}
	

	
	
	public void save(EmployeeOne emp) {
		// TODO Auto-generated method stub
		em.persist(emp);
		em.getTransaction().commit();
		
	}

	public List<EmployeeOne> findbysal(double low, double high) {
		// TODO Auto-generated method stub
		
		Query query=em.createQuery("FROM EmployeeOne WHERE salary  BETWEEN :lower AND :higher");
		query.setParameter("lower", low);
		query.setParameter("higher", high);
		
		List<EmployeeOne> emplist=query.getResultList();
		
		
		
		return emplist;
	}

	public List<EmployeeOne> findbydeptname(String name) {
		// TODO Auto-generated method stub
		TypedQuery<EmployeeOne> query = em.createQuery(
				"SELECT e FROM EmployeeOne e", EmployeeOne.class);
				return query.getResultList();
		Query query=em.createQuery("SELECT e FROM EmployeeOne e WHERE e.dname = : name");
		query.setParameter("name", name);
		
		
		List<EmployeeOne> emplist=query.getResultList();
		
		
		
		return emplist;
	}

}
