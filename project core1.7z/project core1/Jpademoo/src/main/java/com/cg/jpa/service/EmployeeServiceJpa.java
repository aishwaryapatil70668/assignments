package com.cg.jpa.service;

import java.util.List;

import com.cg.jpa.dto.EmployeeOne;

public interface EmployeeServiceJpa {

	public void addemp(EmployeeOne emp);
	public List<EmployeeOne> serachbysal(double low,double high);
	public List<EmployeeOne> searchbydeptname(String name);
	
	
}
