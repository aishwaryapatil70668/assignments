package com.cg.jpa.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

public class EmployeeService {

	public static void main(String args[])  
    {  
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("demoemployee");  
        EntityManager em=emf.createEntityManager();  
          
        em.getTransaction().begin();  
    
        Address add1=new Address();
        add1.setCity("pune");
        add1.setPincode(1002232);
        add1.setState("maha");
        
        Department dep=new Department();
        dep.setId(10031);
        dep.setName("JAVA");
        
        Department dep2=new Department();
        dep2.setId(100311);
        dep2.setName(".net");
        
        EmployeeOne s1=new EmployeeOne(); 
        s1.setId(11301322);
        s1.setName("yasha");
        s1.setSalary(10000);
        s1.setType(true);
        s1.setDateofjoing(new Date());
        s1.setAdd(add1);
        s1.setDep(dep);
        
        EmployeeOne s2=new EmployeeOne(); 
        s2.setId(7211232);
        s2.setName("yasha");
        s2.setSalary(10000);
        s2.setType(true);
        s2.setDateofjoing(new Date());
        s2.setAdd(add1);
        s2.setDep(dep2);
        
        EmployeeOne s3=new EmployeeOne(); 
        s3.setId(74111322);
        s3.setName("yasha");
        s3.setSalary(10000);
        s3.setType(true);
        s3.setDateofjoing(new Date());
        s3.setAdd(add1);
        s3.setDep(dep);//this is gor many to one
        /*List<EmployeeOne> emplist= new ArrayList<EmployeeOne>();
        emplist.add(s1);
        emplist.add(s2); 		
        emplist.add(s3);
        dep.setEmplist(emplist);
        */
        
        
        /*dep.getEmplist().add(s1); for list<emp> 
        dep.getEmplist().add(s2);
        dep.getEmplist().add(s3);*/
      // em.persist(s1);
    //   em.persist(s2);
    //   em.persist(s3);
        
        //em.persist(s1);
      //  em.persist(s2);
     // em.persist(s3);
    
       dep.getEmplist().add(s1);
       dep.getEmplist().add(s3);
       dep.getEmplist().add(s3);
        
//Address add=new Address("pune","maharashtra",1002);

      //  EmployeeOne s2=new EmployeeOne(2,"aish",10000,true,new Date(),add); 
        
      
       // EmployeeOne s3=new EmployeeOne(6,"kajal",20000,true,new Date()); 
          
   //em.persist(s1);  
  
   
//   em.persist(s1); 
//   em.persist(s3);  
  

/*EmployeeOne s=em.find(EmployeeOne.class,1);  
System.out.println("Before Updation");  
System.out.println(" id = "+s.getId());  
System.out.println("Name = "+s.getName());  
System.out.println("Salary = "+s.getSalary());  
  */
/*s.setSalary(2000);
  
System.out.println("After Updation");  
System.out.println("Student id = "+s.getId());  
System.out.println("Student Name = "+s.getName());  
System.out.println("Student Age = "+s.getSalary());  
*/






//em.remove(s);  
em.getTransaction().commit(); 


          
  //     emf.close();  
     em.close();  
    }
    }  