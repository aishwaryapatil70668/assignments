package com.cg.jpa.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
@Id
@Column(name="dept_id")
	private int id;
@Column(name="dep_name")
	private String name;

@OneToMany(mappedBy="dep",cascade=CascadeType.ALL)//dep is employee object mappedBy="dep"
private List<EmployeeOne> emplist= new ArrayList<EmployeeOne>();


public List<EmployeeOne> getEmplist() {
	return emplist;
}
public void setEmplist(List<EmployeeOne> emplist) {
	this.emplist = emplist;
}
public Department() {
	
}


public Department(int id, String name, List<EmployeeOne> emplist) {
	super();
	this.id = id;
	this.name = name;
	this.emplist = emplist;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return "Department [id=" + id + ", name=" + name + ", emplist=" + emplist + "]";
}


	
	
}
