package com.cg.book.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class AuthorService {

EntityManagerFactory emf=Persistence.createEntityManagerFactory("book");
EntityManager em=emf.createEntityManager();	




public void create(int id,String name,int no)
{
	em.getTransaction().begin();
	Author aut=new Author(id,name,no);
	aut.setId(id);
	aut.setName(name);
	aut.setNo(no);	
	em.persist(aut);
	em.getTransaction().commit();
}


public void update(int id, String name, int no) {
	 em.getTransaction().begin(); 
	 Author aut = em.find(Author.class, id);
	 if(aut!=null) {
	aut.setName(name);
	aut.setNo(no);
	em.persist(aut);
	em.getTransaction().commit();
	 }
}

public void search(int id) {
	 em.getTransaction().begin(); 
	 Author aut = em.find(Author.class, id);
	 if(aut!=null) {
	System.out.println(aut.getName());
	System.out.println(aut.getNo());
	 }
}

public void remove(int id) {
	 em.getTransaction().begin(); 
	 Author aut = em.find(Author.class, id);
	 if(aut!=null) {
	 em.remove(aut);
	 em.getTransaction().commit();
	 }}

}
