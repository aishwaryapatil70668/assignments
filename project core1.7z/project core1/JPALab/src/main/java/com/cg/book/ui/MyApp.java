package com.cg.book.ui;

import java.util.Scanner;

import com.cg.book.dto.Author;
import com.cg.book.dto.AuthorService;

public class MyApp {

	public static void main(String[] args) {

		
		int ch;
		 do {
			 
			 Scanner in= new Scanner(System.in);
			 
	    	 AuthorService aut=new AuthorService();
	    	 System.out.println("1.Add author");
	 			System.out.println("2.Update author");
	 			System.out.println("3.search author by id");
	 			System.out.println("4.delete author");
	    	 System.out.println("4.Enter your choice");
	    	ch = in.nextInt();
	    	
	    	
	    	 switch(ch) {
	    	 case 1:
	    		 System.out.println("Enter id");
	    		 int id = in.nextInt();
	    		 System.out.println("Enter name");
	    		 String name = in.next();
	    		 System.out.println("Enter mobile");
	    		 int no = in.nextInt();
	    	
	    		aut.create(id, name, no);
	    		 
		       break;
		       
	    	 case 2:
	    		 System.out.println("Enter author id");
	    		 int id1 =in.nextInt();
	    		 System.out.println("Enter author name to update");
	    		 String name1 = in.next();
	    		 System.out.println("Enter author mobile number to update");
	    		 int no1 =in.nextInt();
	    		 aut.update(id1, name1, no1);
	    		 break;
	    		 
	    	 case 3:
	    		 System.out.println("Enter author id");
	    		 int id3 =in.nextInt();
	    		 aut.search(id3);
	    		 
	    	 case 4:
	    		 System.out.println("Enter emp id to remove");
	    		 int id2 = in.nextInt();
	    		 aut.remove(id2);
	    		 break;
	    	 }
		 }while(ch<4);
		       
		
		

	}

}
