package com.cg.book.ui;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.book.dto.Author;
import com.cg.book.dto.AuthorBookService;
import com.cg.book.dto.AuthorService;
import com.cg.book.dto.Book;

public class MyApplicationLabTwo {

	
	
	
	public static void main(String[] args) {

		
	
		
		 EntityManagerFactory emf=Persistence.createEntityManagerFactory("books_issued");  
	        EntityManager em=emf.createEntityManager();  
	          int ch;
	          Author a= new Author();
	          Book b= new Book();
	          do
	          {
	        	 
	        Scanner in= new Scanner(System.in);
			 
	    	 AuthorBookService aut=new AuthorBookService();
	    	 System.out.println("1.Add author");
	 			System.out.println("2.Update author");
	 			System.out.println("3.search author by id");
	 			System.out.println("4.delete author");
	    	 System.out.println("4.Enter your choice");
	    	ch = in.nextInt();
	    	
	    	
	    	 switch(ch) {
	    	 case 1:
	    		 System.out.println("Enter author id");
	    		 int id = in.nextInt();
	    		 System.out.println("Enter name");
	    		 String name = in.next();
	    		 System.out.println("Enter mobile");
	    		 int no = in.nextInt();
	    		 System.out.println("Enter isbn");
	    		 int id1 = in.nextInt();
	    		 System.out.println("Enter book title");
	    		 String name1 = in.next();
	    		 System.out.println("enter price");
	    		 double price=in.nextDouble();
	    		/* Book b= new Book(id1,)
	    		 Author a= new Author(id,name,no);
	    	*/
	    	a.setBooks(books);
		       break;
	    	 }
	}while(ch<3);
	
	      /*  Set<Book> books=new HashSet<Book>(); 
	        books.add(new Book(1,"star",100.0));
	        books.add(new Book(1,"star",100.0));
	        books.add(new Book(1,"star",100.0));
	        books.add(new Book(1,"star",100.0));
	            
	        Author autt=new Author(2,"aishwarya",45433453);
	           */
	             
		

	}

}
