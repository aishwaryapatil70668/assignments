package com.cg.book.dto;

public class Book {

}
