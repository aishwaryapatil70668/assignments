package com.cg.lab.dto;

import java.util.Scanner;

public class Occ {
	
	static final int MAX_CHAR = 256; 

	 static void count(String str) 
	    { 
		 
		 
		 
		 int count[] = new int[MAX_CHAR];
	        
	        char[] ch = str.toCharArray(); 
	     
	        
	        for (int i = 0; i < ch.length; i++) { 
	        	count[str.charAt(i)]++; 
	        	ch[i] =str.charAt(i); 
	                int find = 0; 
	                for (int j = 0; j <= i; j++) { 
	     
	                    if (str.charAt(i) == ch[j])  
	                        find++;                 
	                } 
	      
	                if (find == 1)  
	                    System.out.println("Number of Occurrence of " + 
	                     str.charAt(i) + " is:" + count[str.charAt(i)]);             
	            } 
	  
	                
	        } 
	    
	    public static void main(String[] args) 
	    { 
	        String str = "aabb"; 
	        count(str); 
	    } /*
    public static void main(String[] args) 
    { Occ o=new Occ();
        Scanner sc = new Scanner(System.in); 
        String str = "aa"; 
        o.geChar(str); 
    } */
}
