package com.cg.lab.dto;

import java.util.Scanner;





public class Descending {

public int getSecon(int n[])
	{
		
		
		int n1=0,n2=0,temp;
		
		for(n1=0;n1<n.length;n1++)
		{
			for(n2=n1+1;n2<n.length;n2++)
			{
				
				if(n[n1]<n[n2])
				{
					temp=n[n1];
					n[n1]=n[n2];
					n[n2]=temp;
					
				}
				
			}
	
		}
		for(n1=0;n1<n.length-1;n1++)
		{
		System.out.println(n[n1]+"");
		}
		System.out.println(n[n.length-1]);
		
		return n[n1];
	}

		public static void main(String[] args) {
			int n,b ,i=0;
			
			SecondSmall sm=new SecondSmall();
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter number of elements \n");
			n=s.nextInt();
			
			int[] a=new int[n];
			System.out.println("enter elements");
			
			for(i=0;i<n;i++)
			{
				a[i]=s.nextInt();
			}
			
			b=sm.getSecon(a);
			
			System.out.println(b);

	}

	}

	

