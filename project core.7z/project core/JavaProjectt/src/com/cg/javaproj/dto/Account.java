package com.cg.javaproj.dto;

public class Account {

}
