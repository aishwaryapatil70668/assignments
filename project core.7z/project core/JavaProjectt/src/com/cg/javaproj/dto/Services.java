package com.cg.javaproj.dto;

public interface Services {

	
	public User createrReg(User u);
	public User login(User user);
	
}
