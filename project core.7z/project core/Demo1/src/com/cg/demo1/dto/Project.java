package com.cg.demo1.dto;

public class Project {

	private int project;
	private String projectName;
	private String projectDesc;
	private double cost;
	
	
	public int getProject() {
		return project;
	}
	public void setProject(int project) {
		this.project = project;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectDesc() {
		return projectDesc;
	}
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Project [project=" + project + ", projectName=" + projectName + ", projectDesc=" + projectDesc
				+ ", cost=" + cost + "]";
	}
	
	
	
}
