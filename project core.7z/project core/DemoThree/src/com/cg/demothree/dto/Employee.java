package com.cg.demothree.dto;

import java.math.BigDecimal;

public class Employee {

	private int empId;
	private String empname;
	public static double pf=10.2;
	private BigDecimal salary;
	private double increament;
	
	public Employee() {
		
	}
	
	public BigDecimal takeHomeSalary()
	{
		BigDecimal in=BigDecimal.valueOf(this.increament);
		
		BigDecimal pfa=BigDecimal.valueOf(this.pf);
		
		BigDecimal tsal=this.salary.add(this.salary.multiply(in)).subtract(pfa);
		
		return tsal;
	}
	public String getName()
	{
		return this.empname+"\tcapgemini";
	}
	
	
	public Employee(int empId, String empname, BigDecimal salary, double increament) {
	//	super();
		this.empId = empId;
		this.empname = empname;
	//	this.pf = pf;
		this.salary = salary;
		this.increament = increament;
		
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}
/*
	public double getPf() {
		return pf;
	}

	public void setPf(double pf) {
		this.pf = pf;
	}
*/
	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public double getIncreament() {
		return increament;
	}

	public void setIncreament(double increament) {
		this.increament = increament;
		}

	
	
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empname=" + empname + ", pf=" + pf + ", salary=" + salary
				+ ", increament=" + increament + "]";
	}
	
}
