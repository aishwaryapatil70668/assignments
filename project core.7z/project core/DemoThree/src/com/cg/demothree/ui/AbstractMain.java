package com.cg.demothree.ui;

public class AbstractMain {

	public static void main(String[] args) {
		
		
		
		AbstractTime t=new DayShift();  //run time polymorphism
		t.login();
		t.logout();
		t.getCompany();
		
		System.out.println(t.time);
		
		
		
	}

}
