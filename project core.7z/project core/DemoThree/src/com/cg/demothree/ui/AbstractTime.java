package com.cg.demothree.ui;

public abstract class AbstractTime {

	double time =9.3;
	
	
	public abstract void login();
	
	public abstract double logout();
	
	public String getCompany() {
		
		return "capge";
		
	}
	
	
}
