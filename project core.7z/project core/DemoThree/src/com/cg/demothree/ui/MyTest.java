package com.cg.demothree.ui;

import java.math.BigDecimal;

import com.cg.demothree.dto.Employee;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Employee emp=new Employee(100,"aishwarya", new BigDecimal(30000),0.1);
 Employee.pf=1300;
	System.out.println("employee id = "+emp.getEmpId());
	System.out.println(emp.takeHomeSalary());
	System.out.println("employee name ="+emp.getName());
	System.out.println("pf is ="+Employee.pf);
	
	
			Employee empone=new Employee(101,"abc",new  BigDecimal(20000),0.2);
			System.out.println("employee id = "+empone.getEmpId());
			System.out.println(empone.takeHomeSalary());
			System.out.println("employee name = "+empone.getName());
			System.out.println("pf is = "+Employee.pf);
			
			
	}

}
