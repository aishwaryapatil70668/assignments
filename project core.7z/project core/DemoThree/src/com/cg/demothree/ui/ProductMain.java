package com.cg.demothree.ui;

import java.util.Scanner;

import com.cg.demothree.dto.Product;
import com.cg.product.service.ProductService;
import com.cg.product.service.productInter;



public class ProductMain {

	public static void print()
	{
		
		
		System.out.println("1.add \n 2.show");
		System.out.println("exit");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		print();
		productInter service=new ProductService();
		Scanner sc=new Scanner(System.in);
		int ch=0;
		do
		{	Product pro=new Product();
			System.out.println("enter choice");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				
			
				System.out.println("add");
				System.out.println("enter id \n");
				int id=sc.nextInt();
				System.out.println("enter name \n");
				String name=sc.next();
				System.out.println("enter price \n");
				double price=sc.nextInt();
				System.out.println("enter description \n");
				String desc=sc.next();
				
				pro.setId(id);
				pro.setName(name);
				pro.setPrice(price);
				pro.setDescr(desc);
			service.addp(pro);
				
				
				break;
			case 2: 
				System.out.println("show");
				Product[] product=service.show();
				for(Product produc:product)
				{
					System.out.println(produc.getId());
					System.out.println(produc.getName());
					System.out.println(produc.getPrice());
					System.out.println(produc.getDescr());
				}
				
				
				
				
				
				break;
			case 3:
				System.exit(0);
				break;
				
				
				
			}
			
			
		}while(ch!=3);
		
		
	}

}



