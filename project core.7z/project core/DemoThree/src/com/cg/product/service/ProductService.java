package com.cg.product.service;

import com.cg.demothree.dto.Product;
import com.cg.product.dao.ProducDao;
import com.cg.product.dao.ProductDao;

public class ProductService implements productInter{

	ProductDao dao;
	
	
	public ProductService()
	{
		
		dao=new ProducDao();
		
	}
	
	
	
	
	
	@Override
	public Product addp(Product prod) {
		// TODO Auto-generated method stub
		
		
		
		return dao.addp(prod);
	}

	@Override
	public Product[] show() {
		// TODO Auto-generated method stub
		return dao.show();
	}

}
