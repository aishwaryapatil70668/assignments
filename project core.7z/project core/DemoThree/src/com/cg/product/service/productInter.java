package com.cg.product.service;

import com.cg.demothree.dto.Product;

public interface productInter {

	
	public  Product addp(Product prod);
	public Product[] show();
	
	
}
