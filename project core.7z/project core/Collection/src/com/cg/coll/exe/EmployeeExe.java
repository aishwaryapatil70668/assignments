package com.cg.coll.exe;

public class EmployeeExe extends  RuntimeException{

	
	public   EmployeeExe()
	{
		super();
	}
	

	public   EmployeeExe (String msg)
	{
		super(msg);
	}

}
