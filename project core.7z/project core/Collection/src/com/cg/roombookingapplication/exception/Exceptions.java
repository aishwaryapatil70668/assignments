package com.cg.roombookingapplication.exception;

public class Exceptions {

}
