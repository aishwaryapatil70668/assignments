package com.cg.collection.ui;

import java.util.ArrayList;
import java.util.List;

public class Arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list=new ArrayList<String>();
		list.add("c");
		list.add("a");
		list.add("b");
		list.add("c");
		System.out.println(list);
System.out.println(list.get(0));		
System.out.println(list.remove("c"));
System.out.println(list.set(2, "o"));

System.out.println(list);



		
		
		
	}

}
