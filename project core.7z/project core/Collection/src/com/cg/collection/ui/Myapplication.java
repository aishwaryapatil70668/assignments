package com.cg.collection.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Myapplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
	Class.forName("com.mysql.jdbc.Driver");

Connection con=	DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "Capgemini123");
PreparedStatement pst=con.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
Scanner s=new Scanner(System.in);
System.out.println("enter id");
int id=s.nextInt();
System.out.println("enter name");
String name=s.next();

System.out.println("enter sal");
double sal=s.nextDouble();


pst.setInt(1, 1001);
pst.setString(2, "abcd");
pst.setDouble(3, 100.1);
pst.executeUpdate();
System.out.println("conncetion done");
	} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
		System.out.println("driver not loaded");
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("conncetion not done");
		}

	}

}
