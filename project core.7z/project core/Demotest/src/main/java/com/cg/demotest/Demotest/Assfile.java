package com.cg.demotest.Demotest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.StringTokenizer;

public class Assfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Reader fread=null;
		
		Writer fwriter=null;
		
		BufferedReader bread =null;
		BufferedWriter bwrite=null;
		
		try {
		fread=new FileReader("myread.txt");
		bread=new BufferedReader(fread); 
		fwriter=new FileWriter("mywriteer.txt");
		bwrite=new BufferedWriter(fwriter);
		
		String data=null;
		
			while((data=bread.readLine())!=null)//full string its read not character wise
			{
				StringTokenizer st=new StringTokenizer(data,":");
				
			String token=null;
				
				while(st.hasMoreTokens())
				{
					
					token= st.nextToken();
					
					String s=st.nextToken(":");
					
					bwrite.write(s);
					
				
					System.out.println(s);
					
					
				}
				
				
				
				
				
				//bwrite.write(data);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
		}finally
		{
			try {
				bread.close();
				bwrite.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("file not close");
			}
			
		
		
		}
		
		
		}

}
