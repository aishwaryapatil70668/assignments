package com.cg.collections.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.collections.dto.Employee;
import com.cg.collections.exception.EmployeeExe;
import com.cg.collections.service.EmployeeService;
import com.cg.collections.service.EmployeeServiceImpl;



public class EmployeeMain {
	
	
	static EmployeeService service;
	
	public static void main(String[] args) {
		service =new EmployeeServiceImpl();
		Scanner sc=new Scanner(System.in);
		int ch;
		do
		{
			System.out.println("1.add employee");
			System.out.println("2.show");
			System.out.println("3.Search by name");
			System.out.println("4.update");
			
			System.out.println("Enter the choice");
			ch=sc.nextInt();
			switch(ch)
			{
			
			case 1:
				System.out.println("enter id");
				int id=sc.nextInt();
				
				System.out.println("enter name");
				String name=sc.next();
				
				System.out.println("enter salary ");
				double sal=sc.nextDouble();
				
				
				Employee emp=new Employee();
				emp.setId(id);
				emp.setName(name);
				emp.setSalary(sal);
				
				service.addemp(emp);
				
				break;
			case 2: 
				
				List<Employee> mylist=service.showall();
						
			
				for(Employee empdata: mylist)
						{
							
							System.out.println("id is ="+empdata.getId());
							System.out.println("name is ="+empdata.getName());
							System.out.println("salary is ="+empdata.getSalary());
							System.out.println();
							
						}
						
				
				break;
				
				
			case 3:
				System.out.println("enter the employee name");
				String sname=sc.next();
				List<Employee> empsearch =service.searchName(sname);
				for(Employee empAll:empsearch)
				{
					
					System.out.println("id is "+empAll.getId());
				}
				
				
				break;
				
			case 4:
				System.out.println("enter the employee id");
				int sid=sc.nextInt();
				try
				{
				Employee empsearchid =service.searchid(sid);
				if(empsearchid!=null)
				{
				System.out.println(empsearchid);
				System.out.println("enter salary");
			
				double salary=sc.nextDouble();
				
				empsearchid.setSalary(salary);
				
				service.update(empsearchid);
				}
				
				}catch(EmployeeExe e)
				{
					
					System.out.println(e.getMessage());
				}
				
				break;
				
			}
			
			
			
		}while(ch!=6);
		
		
	
		
		
	}

}
