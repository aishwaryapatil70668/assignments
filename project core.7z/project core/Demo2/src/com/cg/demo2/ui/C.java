package com.cg.demo2.ui;

public interface C {


	
	public void getd();
	public void print();
	
	default void getde()
	{
		System.out.println("in default");
	}
	
	static void getstat()
	{
		System.out.println("in  static C INterf");
	}
	
}
