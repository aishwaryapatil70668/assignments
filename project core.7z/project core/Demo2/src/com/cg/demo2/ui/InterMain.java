package com.cg.demo2.ui;

public class InterMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		C in=new A();
		in.getde();
		
		A demo = new A();
		A.getstat();
		
		
		
		
	}

}
