package com.cg.demoCollection.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.demoCollection.dto.Employee;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		System.out.println("hashset");
//		Set<String> set=new HashSet<String>();
//		set.add("K");
//		set.add("B");
//		set.add("B");
//		set.add("H");
//		System.out.println(set);
//		
//		System.out.println("hashset emp ");
//		Employee emp=new Employee(10,"A",234);
//		Employee emp1=new Employee(10,"G",234);
//		Employee emp2=new Employee(10,"B                                                            ",234);
//		
//		
//		
//		Set<Employee> sete=new HashSet<Employee>();
//		
//	sete.add(emp);
//	sete.add(emp1);
//	
//	sete.add(emp2);
//	System.out.println(sete);
//	System.out.println("treeset");
//	Set<String> mset=new TreeSet<String>();
//	mset.add("Y");
//	mset.add("L");
//	mset.add("A");
//	mset.add("K");
//	mset.add("Y");
//	System.out.println(mset);
//	
System.out.println("using compareto sorting");	
	Employee empp=new Employee(101,"Z",400);
	Employee empp1=new Employee(11,"C",500);
	Employee empp2=new Employee(17,"b",300);
	
	Set<Employee> setemp=new TreeSet<Employee>();
	
		setemp.add(empp);
		setemp.add(empp1);
		setemp.add(empp2);
		System.out.println(setemp);
		
	  
		System.out.println("sort using hashset");
		Set<Employee> setempp=new HashSet<Employee>();
		
		setemp.add(empp);
		setemp.add(empp1);
		setemp.add(empp2);
		System.out.println(setemp);
		
		
		 List<Employee> list2 = new ArrayList<Employee>(setempp); 
	        Collections.sort(list2); 
	  //casting in list
		System.out.println(list2);
		
		
		
		
		
	}

}
