package com.cg.demoCollection.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.demoCollection.dto.EmpSorting;
import com.cg.demoCollection.dto.Employee;

public class EmpSortingMain {

	
//	
//	
//	
//	public static void before() {
//		Set set = new TreeSet();
//		set.add("2");
//		set.add(3);
//		set.add("1");
//		Iterator it = set.iterator();
//		while (it.hasNext())
//		System.out.print(it.next() + " ");
//		}
//	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee empp=new Employee(101,"Z",400);
		Employee empp1=new Employee(11,"C",500);
		Employee empp2=new Employee(17,"b",300);
		
		List<Employee> list=new ArrayList<Employee>();
		
		list.add(empp);
		list.add(empp1);
		list.add(empp2);
		Collections.sort(list, new EmpSorting());
		System.out.println(list);

	}

}
