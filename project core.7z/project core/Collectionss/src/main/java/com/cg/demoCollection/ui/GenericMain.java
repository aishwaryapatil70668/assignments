package com.cg.demoCollection.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.cg.demoCollection.dto.EmpGeneric;
import com.cg.demoCollection.dto.EmpSorting;
import com.cg.demoCollection.dto.Employee;

public class GenericMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
EmpGeneric<Integer,Double> empp=new EmpGeneric<Integer,Double>(101,"er",4000.0);
EmpGeneric<BigInteger,BigDecimal> empp1=new EmpGeneric<BigInteger,BigDecimal>(new BigInteger("112"),"DFG",new BigDecimal(99.9));

		
		List<EmpGeneric> list=new ArrayList<EmpGeneric>();
		
		list.add(empp);
		list.add(empp1);
		
		//Collections.sort(list, new EmpSorting());
		System.out.println(list);
		
		
		
		
		
		
		
	}

}
