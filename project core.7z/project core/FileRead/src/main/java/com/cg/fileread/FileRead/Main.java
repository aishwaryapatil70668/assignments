package com.cg.fileread.FileRead;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Reader fread=null;
		Writer fwrite=null;
		BufferedReader bread=null;
		BufferedWriter bwrite=null;
		
		try {
			
			
			fread=new FileReader("my.txt");
			bread=new BufferedReader(fread); //temparory data stores... stores data of fread and transferer
			
			fwrite=new FileWriter("mywrite.txt");
			bwrite=new BufferedWriter(fwrite);
			
			int data=0;
			while( (data = fread.read())>=0)
			{
				fwrite.write(data); //writing 
				
				
			}
		}catch (FileNotFoundException e) {
			
			System.out.println("file not found");
		} catch (IOException e) {
			System.out.println("file not read");
			
		}finally
		{
			try {
				fread.close();
				fwrite.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("file not close");
			}
			
			
		}
		
	}

}

