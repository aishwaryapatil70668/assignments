package com.cg.done.dao;

import com.cg.done.dto.Product;

public class ProductDao {

Product prod[];
	
	
	public ProductDao()
	{
		prod=new Product[5];
		
	}
	public Product addp(Product pro) {
		// TODO Auto-generated method stub
		
	for(int i=0;i<prod.length-1;i++)
	{
		prod[i]=new Product();
		prod[i].setId(pro.getId());
				prod[i].setName(pro.getName());	
						prod[i].setPrice(pro.getPrice());
						prod[i].setDescr(pro.getDescr());
	}
		
		
		return pro;
	}

	public Product[] show() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
