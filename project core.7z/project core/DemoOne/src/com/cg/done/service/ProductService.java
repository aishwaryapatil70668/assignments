package com.cg.done.service;

import com.cg.done.dto.Product;

public class ProductService implements IProductService{

	@Override
	public Product addp(Product prod) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product[] show() {
		// TODO Auto-generated method stub
		return null;
	}

}
