package com.cg.inter.ui;

public class ClassD implements InterB {

	@Override
	public void gdata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setData() {
		// TODO Auto-generated method stub
		
	}

}
