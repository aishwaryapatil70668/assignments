package com.cg.inter.ui;

public class Override {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   B a=new C(300);
   a.print();
	}
}

class B
{
	
	B(int x)
	{ 
		System.out.println("hiiii");
		print();
	}
	
	void print()
	{
		System.out.println("class B");
	}}
 class C extends B
 {
	 private int x=34;
	 
	 C(int x)
	 
	 { super(23);
		 this.x=x;
	 }
	 
	 @java.lang.Override
	public String toString() {
		return "C [x=" + x + "]";
	}

	public void print()
	 {
		 //int x=30;
		 System.out.println(x);
	 }
 }