package com.cg.inter.ui;

public class InterMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Timing t=new Day();
		t.login();
		t.logout();
		
		
		System.out.println(Timing.time);
		
		
		
	}
	

}
