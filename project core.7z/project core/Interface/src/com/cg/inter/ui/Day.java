package com.cg.inter.ui;

public class Day implements Timing{

	@Override
	public void login() {
	System.out.println("login");
	}

	@Override
	public void logout() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void company() {
		// TODO Auto-generated method stub
		
	}

}
