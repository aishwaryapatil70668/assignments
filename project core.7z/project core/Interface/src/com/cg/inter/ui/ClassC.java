package com.cg.inter.ui;

public class ClassC implements  InterB, InterA{

	@Override
	public void setData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void gdata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

}
