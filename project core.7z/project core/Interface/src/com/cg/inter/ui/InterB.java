package com.cg.inter.ui;

public interface InterB extends InterA{
	
	public void setData();

}
