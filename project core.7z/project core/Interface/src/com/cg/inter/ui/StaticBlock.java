package com.cg.inter.ui;

abstract class D {

		static int x=10;
		static {
			
			System.out.println("in a");
		}
}
		
public  class StaticBlock extends D {

		public static void main(String[] args) {
		
			
		//	D a= new D();
			
			System.out.println("main");
			//A.x=55;
			
			//Class.forName("com.cg.inter.ui.A");
		System.out.println();
//	
		}

}




