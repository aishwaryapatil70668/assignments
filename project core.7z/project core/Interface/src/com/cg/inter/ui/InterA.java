package com.cg.inter.ui;

public interface InterA {

	public void gdata();
	public void print();
//	void setData();
	
	static void hello()
	{
		System.out.println("hello");
	}
	
	
}
