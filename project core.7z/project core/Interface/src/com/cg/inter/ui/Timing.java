package com.cg.inter.ui;

public interface Timing {
	
	
	static double time=9.6;
	
	public void login();
	public void logout();
	public void company();
	
	
}
